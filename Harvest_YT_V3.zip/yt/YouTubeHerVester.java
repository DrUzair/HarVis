package yt;

import javax.swing.JTextArea;

import yt.har.uTubeCampaignManager;

public interface YouTubeHerVester {
	public JTextArea textAreaDM = new JTextArea(35,80);
	public JTextArea textAreaUodOutput = new JTextArea(20, 50);
	public JTextArea textAreaClient = new JTextArea(35,80);
	public final yt.har.uTubeCampaignManager campaignManager = new uTubeCampaignManager();
	public  JTextArea textAreaTM = new JTextArea(35,80);
	public JTextArea textAreaCrawler = new JTextArea(35,80);
}
