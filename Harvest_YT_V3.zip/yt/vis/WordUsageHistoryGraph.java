package yt.vis;

import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;
import java.util.Date;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import yt.har.uTubeDataManager;
import yt.vis.WordUsageHistory.WordUsage;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.BubbleChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.StackedBarChart;
import javafx.scene.chart.XYChart;

 
public class WordUsageHistoryGraph {  
    public static JPanel panel = new JPanel();
    uTubeDataManager dataManager;
    ArrayList<WordUsageHistory> listOfWordUsageHistories = new ArrayList<WordUsageHistory>();
    public WordUsageHistoryGraph(uTubeDataManager dataManager) {
		this.dataManager = dataManager;
	}
    @SuppressWarnings("unchecked")
	void wordUsageHistogram(JFXPanel uploadHistogramFxPanel){    	
    	fetchWordUsageHistoryData();
        //stage.setTitle("Upload Histogram");
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        final LineChart<String,Number> lineChart = new LineChart<String,Number>(xAxis,yAxis);
        lineChart.setTitle("UoD Word Usage History");
       
        XYChart.Series<String, Number> series1 = new XYChart.Series<String, Number>();
        XYChart.Series<String, Number> series2 = new XYChart.Series<String, Number>();
        series1.setName("Videos");
        series2.setName("Content Authors");
        //Set dataSet = data.entrySet();
        
        ArrayList<XYChart.Series<String, Number>> listOfDataSeries = new ArrayList<XYChart.Series<String,Number>>();
        
        Iterator<WordUsageHistory> listOfWordUsageHitsIter = listOfWordUsageHistories.iterator();
        while (listOfWordUsageHitsIter.hasNext()){ 	
        	WordUsageHistory wordUsageHistory = (WordUsageHistory)listOfWordUsageHitsIter.next();
        	XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();
        	series.setName(wordUsageHistory.word);
        	Iterator<WordUsageHistory.WordUsage> wordUsageListIter = wordUsageHistory.wordUsageList.iterator();
        	while (wordUsageListIter.hasNext()){
        		WordUsageHistory.WordUsage wordUsage = (WordUsageHistory.WordUsage)wordUsageListIter.next();
        		series.getData().add(new XYChart.Data<String, Number>(wordUsage.timePeriod, wordUsage.usageFreq));        		
        	}
        	listOfDataSeries.add(series);
        }
        
        xAxis.setLabel("Time Period");        
        yAxis.setLabel("Usage Frequency");
        
        Scene scene  = new Scene(lineChart,1100,750);
        
        Iterator<XYChart.Series<String, Number>> listOfDataSeriesIter = listOfDataSeries.iterator();
        while (listOfDataSeriesIter.hasNext()){
        	lineChart.getData().add((XYChart.Series<String, Number>)listOfDataSeriesIter.next());
        }       
        uploadHistogramFxPanel.setScene(scene);
    }
  
    void fetchWordUsageHistoryData(){   	    	
    	try{    		
    		Connection conn = dataManager.getDBConnection();
    		System.out.println("DB Connection Secured.\n");
    		
    		// FIND Most Used UoD Words
    		Statement mostUsedWordsQuery = conn.createStatement();
			ResultSet mostUsedWordsResultSet = mostUsedWordsQuery.executeQuery(
			"SELECT DISTINCT(Word) FROM UOD_Titles "+
			"WHERE WordCOunt > 500 "+
			"ORDER BY WordCount DESC");
			System.out.println("Most Used UoD Words fetched.\n"); 
    		
			while (mostUsedWordsResultSet.next()){
				String word = mostUsedWordsResultSet.getString("Word");
				Statement wordUsageHistoryQuery = conn.createStatement();
				ResultSet wordUsageHistoryResultSet = wordUsageHistoryQuery.executeQuery(
				"SELECT Date_format(CreatedOn, '%Y %M') AS UploadTime, "+
				"COUNT(Title) AS Freq, "+ 
				"COUNT(DISTINCT(Author)) AS AuthCount from utubevideos "+
				"WHERE Title LIKE '%"+ word +"%' "+
				"GROUP BY  UploadTime "+
				"ORDER BY CreatedOn");
				System.out.println("WordUsageHistory Data for <"+ word +"> fetched.\n"); 
				
				WordUsageHistory wordUsageHistory = new WordUsageHistory();
				wordUsageHistory.word =  word;
				while(wordUsageHistoryResultSet.next()){
					WordUsageHistory.WordUsage wordUsage = wordUsageHistory.new WordUsage();				
					wordUsage.timePeriod = wordUsageHistoryResultSet.getString("UploadTime");
					wordUsage.usageFreq = wordUsageHistoryResultSet.getInt("Freq");
					wordUsage.authorsCount = wordUsageHistoryResultSet.getInt("AuthCount");
					
					wordUsageHistory.wordUsageList.add(wordUsage);
				}
				listOfWordUsageHistories.add(wordUsageHistory);
			}
			
			
//			int rowCount = 0;
//			while(wordUsageHistoryResultSet.next()){
//				rowCount++;
//			}
//			
//			String [][]dataArray = new String[3][rowCount];
//			rowCount = 0;
//			wordUsageHistoryResultSet.beforeFirst();
//			while(wordUsageHistoryResultSet.next()){
//		        	String year = wordUsageHistoryResultSet.getString("UploadTime");		        	     
//		        	String freq = wordUsageHistoryResultSet.getString("Freq");
//		        	String authorCount = wordUsageHistoryResultSet.getString("AuthCount");       			 
//		        					
//		        	dataArray[0][rowCount]= year;
//		        	dataArray[1][rowCount]= freq;
//		        	dataArray[2][rowCount]= authorCount; 
//		        	rowCount++;
//		    }
			conn.close();
			System.out.println("DB Connection Closed.\n");			
    	}
	    catch (SQLException e){
	    	System.out.println("SQL code does not execute." + e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  	
    	
    }
    
    public void initAndShowGUI() {
        // This method is invoked on the EDT thread
        
        final JFXPanel uploadHistogramFxPanel = new JFXPanel();        
        panel.add(uploadHistogramFxPanel);       
        panel.setVisible(true);    

        Platform.runLater(new Runnable() {
            @Override
            public void run() {           
            	wordUsageHistogram(uploadHistogramFxPanel);           
            }
       });        
    }
    private void initFX(JFXPanel fxPanel) {
    	wordUsageHistogram(fxPanel);    	
    }      
    public void fire() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            initAndShowGUI();
            }
        });
    }
}

class WordUsageHistory {
	ArrayList<WordUsageHistory.WordUsage> wordUsageList = new ArrayList<WordUsageHistory.WordUsage>();  
	String word;
class WordUsage{	
		String timePeriod;
		int usageFreq;
		int authorsCount;
	}
}