package yt.vis;

import javax.swing.JPanel;

import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.visualization.RenderContext;
import edu.uci.ics.jung.visualization.renderers.Renderer;

public class GraphViewer<V,E> extends JPanel implements Renderer {

	@Override
	public EdgeLabel getEdgeLabelRenderer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Edge getEdgeRenderer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VertexLabel getVertexLabelRenderer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vertex getVertexRenderer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void render(RenderContext arg0, Layout arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderEdge(RenderContext arg0, Layout arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderEdgeLabel(RenderContext arg0, Layout arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderVertex(RenderContext arg0, Layout arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderVertexLabel(RenderContext arg0, Layout arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setEdgeLabelRenderer(EdgeLabel arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setEdgeRenderer(Edge arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setVertexLabelRenderer(VertexLabel arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setVertexRenderer(Vertex arg0) {
		// TODO Auto-generated method stub
		
	}}