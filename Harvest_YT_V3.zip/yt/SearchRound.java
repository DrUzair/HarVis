package yt;

public class SearchRound {
String fullQueryString;
public String getFullQueryString() {
	return fullQueryString;
}
public void setFullQueryString(String fullQueryString) {
	this.fullQueryString = fullQueryString;
}
public String getTablePostfix() {
	return tablePostfix;
}
public void setTablePostfix(String tablePostfix) {
	this.tablePostfix = tablePostfix;
}
public SearchRound(String fullQueryString, String tablePostfix) {
	super();
	this.fullQueryString = fullQueryString;
	this.tablePostfix = tablePostfix;
}
String tablePostfix;

}
