package yt.har;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import yt.D2I_GUI;
import yt.HarVisEx;
import yt.SearchRound;
import yt.YouTubeHerVester;



public class uTubeDataManager  implements Runnable{
	// Database parameters (Required for getDBConnection())
		private static String dbUser = null;
		private static String dbPassword = null;
		private static String dbURL = null;
		private static String dbSchema = null;
	public static final int STORE_MODE = 0;
	public static final int UoD_MODE = 1;
	public static final int FILTER_MODE = 2;
	private int mode;	
	private boolean keepRunning;
	private boolean dataSaved;	
	//protected uTubeCampaignManager campaignManager;
	protected static YouTubeHerVester harvis;
	protected D2I_GUI d2iGUI;
	//private uTubeClientThreadsManager threadManager;
	static int mainDataCursor;
	//private String Mode;
	HashMap<String, uTubeVideoData> videoDataMap;
	// JDBC Variables
	private Connection dbConnection = null;
	// UoD Parameters
	private int wordCountLimit;
	private int coWordCountLimit;
	private int coOccurCountLimit;
	private String srcTable;
	private String destTable;
	//================================================================================
    // Constructors
    //================================================================================
	// When a DataManager is required for Storing, Filtering, UoD
	public uTubeDataManager(YouTubeHerVester harvisObject, int mode) 
	{
		harvis =  harvisObject;
		keepRunning = true;
		mainDataCursor = 1;	
		this.mode = mode;
	}
	// When a DataManager is required for UoD Discovery
	public uTubeDataManager(D2I_GUI d2iGUI, int wordCoundLimit, int coWordCountLimit, int coOccurCountLimit) 
	{
		this.d2iGUI = d2iGUI;
		keepRunning = true;
		mainDataCursor = 1;	
		this.mode = UoD_MODE;
		setUoD_Param(wordCoundLimit, coWordCountLimit, coOccurCountLimit);
	}
	// When a DataManager is required for fetching data for visualization
	public uTubeDataManager(YouTubeHerVester harvisObject) 
	{
		harvis = harvisObject;
		keepRunning = true;
		mainDataCursor = 1;		
	}
	public void setUoD_Param(int wordCoundLmt, 
			int coWordCountLmt, 
			int coOccurCountLmt){
		wordCountLimit = wordCoundLmt;
		coWordCountLimit = coWordCountLmt;
		coOccurCountLimit = coOccurCountLmt;		
	}
	public void stopRunning(){
		keepRunning = false;
	}

	boolean isDataSaved(){
		return dataSaved;
	}
	
	public void setVideoDataMap(HashMap<String, uTubeVideoData> videoDataMap){
		Set<Entry<String, uTubeVideoData>> dataSet = videoDataMap.entrySet();		
		harvis.textAreaDM.setText("\n\t uTubeDM: Received new batch of " + dataSet.size() +  " videos. \n");
		this.videoDataMap = videoDataMap;
	}
	
	private void storeDataProcess(){
		uTubeVideoData videoData = new uTubeVideoData();
		int localDataCursor = 1;
		Iterator iterator;
		Set dataSet;
		
		while(keepRunning){
			boolean ex = false;
			try{				
				dataSaved = false;
				videoDataMap = harvis.campaignManager.threadManager.getDataReceivedFromCrawler();				
				harvis.textAreaDM.append("\n\t uTubeDM: Storing new batch \n");
				dataSet = videoDataMap.entrySet();			 
				iterator = dataSet.iterator();
				dbConnection = getDBConnection();											
				while(iterator.hasNext()){
					Map.Entry entry = (Map.Entry) iterator.next();
					String ID = (String)entry.getKey();
					videoData = (uTubeVideoData)entry.getValue();
					if ( videoData.isSaved() )
						continue;					
					harvis.textAreaDM.append("\n uTubeDM: Saving data for " + videoData.getTitle());
					//System.out.println(localDataCursor + " " + videoData.getVideoID() + " saving");
					insertVideoRecordIntoDB(videoData);					
					//System.out.println(localDataCursor++ + " " + videoData.getVideoID() + " saved.");
					if (harvis.textAreaDM.getLineCount() > 500)
						harvis.textAreaDM.setText("");
				}			
			}catch(java.util.ConcurrentModificationException concurExc){
				harvis.textAreaDM.append("\n\t uTubeDM: Exception Concur ");
				//concurExc.printStackTrace();
				ex = true;
			}
			catch(Exception e){
				e.printStackTrace();
				harvis.textAreaDM.append("\n\t " + e.getMessage());
				harvis.textAreaDM.append("\n\t uTubeDM: Exception e Video ID " + videoData.getVideoID());
				harvis.textAreaDM.append("\n\t uTubeDM: Exception Video Title " + videoData.getTitle());
				//e.printStackTrace();
				ex = true;
			}	
			if (dbConnection != null) {
				try {
					dbConnection.close();					
					//uTubeClient.textArea.append("\n\t uTubeDM: Connection Closed.\n");
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}	
			if (ex == false){
				dataSaved = true;
				harvis.campaignManager.threadManager.dataSavedSuccessfull();				
			}
		}
	}
	public void run(){
		switch(mode){
			case uTubeDataManager.STORE_MODE:
				storeDataProcess(); break;
			case uTubeDataManager.UoD_MODE:
				discoverUoD_Words(); break;
			case uTubeDataManager.FILTER_MODE:
				filterVideos();
			default:
				storeDataProcess(); break;
		}		
	}
	
	private void filterVideos(){
		try{
			HashMap<String, SearchRound> queryStrings = new HashMap<String, SearchRound>();			
			queryStrings = reloadQueryStrings();			
			HashMap<String, uTubeVideoData> existingVideoData =new HashMap<String, uTubeVideoData>();
			for (Map.Entry<String, SearchRound> entry : queryStrings.entrySet()) {
				existingVideoData.putAll(reLoadVideoDataLite(entry.getKey()));
			}
			
			
			Set<java.util.Map.Entry<String, uTubeVideoData>> videoSet = existingVideoData.entrySet();
			Iterator<java.util.Map.Entry<String, uTubeVideoData>> videoSetIterator = videoSet.iterator();
			int filterCount = 0;
			int relevantCount = 0;
			while(videoSetIterator.hasNext()){
				Map.Entry<String, uTubeVideoData> videoEntry = (Map.Entry<String, uTubeVideoData>) videoSetIterator.next();
				uTubeVideoData videoData = videoEntry.getValue();
				String titleAndDesc = videoData.getTitle() + "\n" + videoData.getDescription();
				harvis.textAreaDM.setText(" Finding Relevance for \n " + videoData.getTitle() + "\n Using Keywords ");
				Set<String> queryStringsKeySet = queryStrings.keySet();
				Iterator<String> queryStringsKeySetIterator = queryStringsKeySet.iterator();
				boolean matchExists = false;
				while (queryStringsKeySetIterator.hasNext()){
					String queryString = (String) queryStringsKeySetIterator.next();	
					harvis.textAreaDM.append("\n " + queryString);
					matchExists = wordsMatchExists(queryString, titleAndDesc);		
					if(matchExists)
						break;
				}					
				if (matchExists == false){
					filterCount++;
					harvis.textAreaDM.append(" NOT RELEVENT \n " );
				}else
					relevantCount++;
			}
			harvis.textAreaDM.append(" Total Videos  " + existingVideoData.size() );
			harvis.textAreaDM.append(" Irrelevant Videos  " + filterCount );
			harvis.textAreaDM.append(" Relevant Videos  " + relevantCount );
			
		}catch(Exception e){
			e.printStackTrace();		 
			harvis.textAreaDM.append("\n Grrrr " + e.getMessage());
			harvis.textAreaClient.append("\n Grrrr " + e.getMessage());			 
		}	
	}
//	public static Connection getDBConnection(String dbUser, String dbUsrPwd, String dbServerUrl) throws SQLException, ClassNotFoundException{
//		Connection conn = null;
//    	Class.forName("com.mysql.jdbc.Driver");    		
//	   	Properties connectionProps = new Properties();
//	    connectionProps.put("user", dbUser);
//	    connectionProps.put("password", dbUsrPwd);
//	    //String connString = "jdbc:mysql://"+dbServerUrl+"/?user="+dbUser+"&password="+dbUsrPwd;
//	    String connString = "jdbc:mysql://"+dbServerUrl+"/?useUnicode=true&amp;characterEncoding=UTF-8";
//	    conn = DriverManager.getConnection(connString, connectionProps);
//    return conn;
//	}
	public static Connection getDBConnection() throws SQLException, ClassNotFoundException {
	    	Connection conn = null;
	    	Class.forName("com.mysql.jdbc.Driver");    		
		   	Properties connectionProps = new Properties();
		    connectionProps.put("user", dbUser);
		    connectionProps.put("password", dbPassword);	    
		    String connString = "";
		    String unicode= "?useUnicode=yes&characterEncoding=UTF-8";
		    if(dbSchema.equals(""))
		    	connString = "jdbc:mysql://"+dbURL+"/?useUnicode=yes&characterEncoding=UTF-8";
		    else
		    	connString = "jdbc:mysql://"+dbURL+"/"+dbSchema+"?useUnicode=yes&characterEncoding=UTF-8";
		    conn = DriverManager.getConnection(connString, connectionProps);
	    return conn;
	}
	public void reLoadVideoDataFull(){
		videoDataMap = new HashMap<String, uTubeVideoData>();
		try {
			Connection conn = getDBConnection();
			Statement selectVideoDataQuery = conn.createStatement();
			ResultSet selectVideoDataQueryResultSet = selectVideoDataQuery.executeQuery("Select * from uTubeVideos");
			int videoCount = 0;
			while(selectVideoDataQueryResultSet.next()){
	        	uTubeVideoData videoData = new uTubeVideoData();
				videoData.setAuthor(selectVideoDataQueryResultSet.getString("Author")); 			// Author
				videoData.setCategory(selectVideoDataQueryResultSet.getString("Category"));			// Category
	        	videoData.setCommentsCount(selectVideoDataQueryResultSet.getInt("CommentsCount")); 	// CommentsCount
	        	videoData.setCreatedOn(selectVideoDataQueryResultSet.getDate("CreatedOn"));			// CreatedOn	
	        	videoData.setDescription(selectVideoDataQueryResultSet.getString("Description"));	// Description
	        	videoData.setDislikesCount(selectVideoDataQueryResultSet.getInt("Dislikes"));		// Dislikes
	        	videoData.setDuration(selectVideoDataQueryResultSet.getString("Duration"));			// Duration 
	        	videoData.setFavoriteCount(selectVideoDataQueryResultSet.getInt("FavoritesCount"));	// FavoritesCount	        	
	        	videoData.setLikesCount(selectVideoDataQueryResultSet.getInt("Likes"));				// LikesCount
	        	videoData.setLocation(selectVideoDataQueryResultSet.getString("Location"));			// Location
	        	URL url = new URL(selectVideoDataQueryResultSet.getString("QueryUrl"));				// QueryUrl	        	
	        	uTubeQuery queryObj = new uTubeQuery(url);
	        	queryObj.setQueryString(selectVideoDataQueryResultSet.getString("QueryString"));	// QueryString
	        	videoData.setQueryObject(queryObj);
	        	videoData.setRating(selectVideoDataQueryResultSet.getFloat("Rating"));				// Rating
	        	videoData.setTitle(selectVideoDataQueryResultSet.getString("Title"));				// Title
	        	videoData.setVideoID(selectVideoDataQueryResultSet.getString("ID"));				// VideoID
	        	videoData.setViewCount(selectVideoDataQueryResultSet.getInt("ViewsCount"));			// ViewsCount
	        	
	        	videoData.setSaved();
	        	videoData.comments = loadVideoCommentsData(videoData);
	        	videoDataMap.put(videoData.getVideoID(), videoData);	 
	        	harvis.textAreaDM.append("\n Video # "+ ++videoCount +" reloaded ");
	        	
	        	if(videoCount > 10)
	        		break;
			}
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		harvis.campaignManager.setReloadedData(videoDataMap);
	}
	Vector<uTubeVideoComment> loadVideoCommentsData(uTubeVideoData videoDataObj){
		Vector<uTubeVideoComment> comments = new Vector<uTubeVideoComment>();
		Connection conn;
		try {
			conn = getDBConnection();
			Statement selectVideoCommentsQuery = conn.createStatement();
			ResultSet selectVideoCommentsQueryResultSet = selectVideoCommentsQuery.executeQuery("Select * from uTubeVideoComments WHERE VideoID=\'" + videoDataObj.getVideoID() + "\'");			 
			while(selectVideoCommentsQueryResultSet.next()){
				uTubeVideoComment commentObj = new uTubeVideoComment();
				commentObj.setAuthor(selectVideoCommentsQueryResultSet.getString("Author"));	// Author
				commentObj.setContent(selectVideoCommentsQueryResultSet.getString("Content"));	// Content
				commentObj.setCreatedOn(selectVideoCommentsQueryResultSet.getDate("CreatedOn"));// CreatedON
				commentObj.setvideo(videoDataObj);
				comments.add(commentObj);
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return comments;
	}
	private void discoverUoD_Words(){		
		// 1. Create a Map of uniqueQueryWords
		HashMap<String, SearchRound> queryStringsMap = reloadQueryStrings();
		Set<String> queryStringsSet = queryStringsMap.keySet();
		Iterator<String> queryStringsSetIter = queryStringsSet.iterator();
		String allQueryStrings = "";
		while(queryStringsSetIter.hasNext()){
			allQueryStrings += queryStringsSetIter.next() + "\n";
		}
		StringReader keyWordsStringReader = new StringReader(allQueryStrings);
		BufferedReader keyWordsReader = new BufferedReader(keyWordsStringReader);
		HashMap<String, String> uniqueQueryWordsMap = new HashMap<String, String>();
		try {
			String keyWordsLine = "";
			String delim = " ";
			while((keyWordsLine = keyWordsReader.readLine()) != null){
				StringTokenizer mustKeyWordsTokenizer = new StringTokenizer(keyWordsLine, delim); 
				while (mustKeyWordsTokenizer.hasMoreTokens()) {
					String word = mustKeyWordsTokenizer.nextToken();
					if (uniqueQueryWordsMap.get(word) == null){						
						uniqueQueryWordsMap.put(word, word);						
					}					
				}				
			}
			keyWordsStringReader.close();
			keyWordsReader.close();
		} catch (IOException e1) {			
			e1.printStackTrace();
		}
		
		// 2. Load words_2b_filtered
		URL fileURL = HarVisEx.class.getResource("Resources/word_2b_filtered");
		String words_2b_filtered = "";
		try {
			System.out.println(fileURL.getFile());
			FileReader fr = new FileReader(fileURL.getFile());
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			words_2b_filtered += line;
			while(line != null){
				System.out.println(line);
				line = br.readLine();
				words_2b_filtered += line;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		// 3. Load Data		
		String strSqlCommand = "";
		ArrayList<ContentItem> contentList = new ArrayList<ContentItem>();
		if (d2iGUI.srcTableName.equals("utubevideocomments")){
			String []contentCols = new String[1];			
			contentCols[0] = "Content";
			strSqlCommand =	"Select Author, Content from utubevideocomments ";
			if (d2iGUI.uodKeywordFilter != null){				
				strSqlCommand += " WHERE Content LIKE '%"+ d2iGUI.uodKeywordFilter+"%'" +
						"OR VideoID IN (Select ID from utubevideos WHERE Title LIKE '%"+ d2iGUI.uodKeywordFilter+"%')";
			}
			contentList = fetchDataFromDB(contentCols, strSqlCommand);
		}else if(d2iGUI.srcTableName.equals("utubevideos")){
			String []contentCols = new String[2];			
			contentCols[0] = "Title";
			contentCols[1] = "Description";
			strSqlCommand =	"Select Author, Title, Description from utubevideos";
			if (d2iGUI.uodKeywordFilter != null){				
				strSqlCommand += " WHERE Title LIKE '%"+ d2iGUI.uodKeywordFilter+"%' OR Description LIKE '%"+ d2iGUI.uodKeywordFilter+"%'";
			}
			contentList = fetchDataFromDB(contentCols, strSqlCommand);
		}
		
		int dataItemNumber = 0;		
		Map<String, Word> wordsMap = new HashMap<String, Word>();
		Iterator<ContentItem> contentListIterator = contentList.iterator();
		while(contentListIterator.hasNext()){
			ContentItem contentItem =  contentListIterator.next();			
			String content  = contentItem.getContent().replaceAll("[^\\u0000-\\uFFFF]",""); // Replace non-alphanumeric characters			
			String author = contentItem.getAuthor();	
			String delim = " \t.,:;?`~!@#$%^&*+-=_/|{}()[]<>\"\'1234567890";
			String strWord;	
			Word newWord;	
			d2iGUI.uodOutputTextArea.setText("\t" + ++dataItemNumber + " Parsing Words for : \n " + (content.length() > 60 ? content.substring(0, 60) : content) + "..." );			
			StringTokenizer st = new StringTokenizer(content, delim); 
			while (st.hasMoreTokens()) {
				strWord = st.nextToken().toLowerCase();	
				if (strWord.length() > 2){
					newWord = (Word) wordsMap.get(strWord); 
					if (newWord == null) {
						newWord = new Word(strWord, 1);
						// Check if the newWord is among the uniqueQueryWords
						if (uniqueQueryWordsMap.get(strWord) != null)
							newWord.isQueryKeyWord = true;
						newWord.addAuthor(author);
						wordsMap.put(strWord, newWord); 
					} else {
						newWord.addAuthor(author);
						newWord.wordCount++;						
					}						
				}
			}						
		}		
	
		// 4. Remove words_2b_filtered from wordsMap
		StringTokenizer st = new StringTokenizer(words_2b_filtered, ","); 
		System.out.println("Words before removal of filterwords.. " + wordsMap.entrySet().size());		
		while (st.hasMoreTokens()) {
			String strFilterWord = st.nextToken().toLowerCase();	
			Word wordObj = wordsMap.get(strFilterWord);
			if (wordObj != null){  
				wordsMap.remove(strFilterWord);		
				d2iGUI.uodOutputTextArea.append(strFilterWord + " removed as filter word \n");
			}
		}
		System.out.println("Words after removal of filterwords .. " + wordsMap.entrySet().size());		
		// 5. Remove Word with less occurrence_count than this.wordCountLimit | this.coWordCountLimit
		Set<Map.Entry<String, Word>> wordsSet = wordsMap.entrySet(); 
		Iterator<Map.Entry<String, Word>> wordsSetIter = wordsSet.iterator();
		d2iGUI.uodOutputTextArea.setText("Removing less frequent words than wordCountLimit ...");
			
		int limit = (this.wordCountLimit < this.coWordCountLimit ? this.wordCountLimit :  this.coWordCountLimit);
		int i = 1;
		while(wordsSetIter.hasNext()){			
			Word wordObj = wordsSetIter.next().getValue();
			
			if(wordObj.wordCount < limit){
				try{
					System.out.println("\n\t Removing " + i++ + " " + wordObj.word + " WordCount " + wordObj.wordCount);
					d2iGUI.uodOutputTextArea.append("\n\t Removing " + wordObj.word + " WordCount " + wordObj.wordCount);
				}catch(Exception e){
					e.printStackTrace();
				}
				if ( d2iGUI.uodOutputTextArea.getLineCount() > 50)
					d2iGUI.uodOutputTextArea.setText("Removing less frequent words than wordCountLimit ...");
				wordsMap.remove(wordObj.word);
				wordsSet = wordsMap.entrySet(); 
				wordsSetIter = wordsSet.iterator();
			}
		}
		
		// Make a wordList and sort the words wrt occurrence_count		
		java.util.List<Word> wordList = new java.util.ArrayList<Word>();
		wordsSet = wordsMap.entrySet(); 
		wordsSetIter = wordsSet.iterator();
		while(wordsSetIter.hasNext()){
			d2iGUI.uodOutputTextArea.setText("Sorting words wrt occurenceCount ...");
			Word wordObj = wordsSetIter.next().getValue();
			wordList.add(wordObj);
		}
		wordsMap.clear();
		wordsMap = null;		
		Collections.sort(wordList, new WordComparator());
		// Prepare words/co-words maps				
		int wordNumber = 0;
		Iterator<Word> wordListIter = wordList.iterator();
		while (wordListIter.hasNext()){
			
			Word wordObj = wordListIter.next();
			boolean isArabicWord = wordObj.word.matches("[ ء-ي]+");			
			if(isArabicWord)
				d2iGUI.uodOutputTextArea.setText("Searching CoWords for " + " (" + wordNumber++ +"/" + wordList.size() +") " +  wordObj.word );
			else				
				d2iGUI.uodOutputTextArea.setText("Searching CoWords for " + wordObj.word + " (" + wordNumber++ +"/" + wordList.size() +")");		
			Iterator<Word> coWordListIter = wordList.iterator();
			if( wordObj.wordCount >= this.wordCountLimit) {
				while (coWordListIter.hasNext()){				
					Word coWordObj = coWordListIter.next();				
					if (wordObj.word.equalsIgnoreCase(coWordObj.word) == false && coWordObj.wordCount >= this.coWordCountLimit &&
							(wordObj.coWords.containsKey(coWordObj.word) == false && coWordObj.coWords.containsKey(wordObj.word) == false)){	
						int coOccurenceCount = getCoOccurenceCount(wordObj, coWordObj);
						if (coOccurenceCount > this.coOccurCountLimit){
							d2iGUI.uodOutputTextArea.append("\n Word \t" + coWordObj.word + " \t Count " + coWordObj.wordCount + " \t CoOccurenceCount " + coOccurenceCount);
							insertUoD_Word_IntoDB(wordObj, coWordObj, coOccurenceCount);
							wordObj.coWords.put(coWordObj.word, coWordObj);
							coWordObj.coWords.put(wordObj.word, wordObj);
						}
					}
				}
			}
		}			
		harvis.textAreaUodOutput.append("\t \t \n Finished");
}
		
	
	/* This Function is to be used by d2i
	 *  
	 */
	public Vector<String> getTableNames(String name){
		Vector<String> tableNamesVector = new Vector<String>();
		try {
			Connection conn = uTubeDataManager.getDBConnection();
			DatabaseMetaData dbmd = conn.getMetaData();
			ResultSet tableNamesResultSet = dbmd.getTables(null, null, name, null);
			while(tableNamesResultSet.next()){
				tableNamesVector.add(tableNamesResultSet.getString(3));
			}	
			return tableNamesVector;
		} catch (ClassNotFoundException e) {			
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public static void createNewDB_Schema(String dbSchemaName){
		try {
			Connection conn = uTubeDataManager.getDBConnection();					
			Statement statement = conn.createStatement();
			String newDB_SQL = "CREATE DATABASE "+ dbSchemaName;
		    statement.executeUpdate(newDB_SQL);		    
			conn.close();			
			JOptionPane.showMessageDialog(null, "Database created successfully.", "I Got It.", JOptionPane.INFORMATION_MESSAGE);			
		} catch (ClassNotFoundException e) {			
			JOptionPane.showMessageDialog(null, "Database driver is not properly installed \n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			return;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Database connection parameters are not correct \n" + e.getErrorCode(), "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		dbSchema = dbSchemaName;
		create_CommentVideoAuthors_Table();
		create_uTubeSearchRound_Table();
		create_uTubeVideoComments_Table();
		create_uTubeVideos_Table("X");
		create_CommentAuthorsProfile_Table();
		create_CommentVideoAuthors_MDVA_Table(); //MDVA (Most Discussed VA)
		createUoD_Table("uod_titles");		
	}
	private static String create_CommentVideoAuthors_Table(){		
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement();  
            String createTableCommand =
       		"CREATE TABLE `commentvideoauthors` ( "+
            " `CommentAuthor` varchar(100) NOT NULL, "+
            " `CommentCount` int(11) DEFAULT NULL, "+
            " `VideoID` varchar(100) DEFAULT NULL, "+
            " `VideoTitle` varchar(500) DEFAULT NULL, "+
            " `VideoAuthor` varchar(100) DEFAULT NULL "+
            " ) ENGINE=InnoDB DEFAULT CHARSET=utf8";
            statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return "CommentVideoAuthors created successfully.";
	}

	private static String create_uTubeSearchRound_Table(){		
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement();  
            String createTableCommand =
            		"CREATE TABLE `utubesearchround` ( "+
            		"  `SeedQueryString` varchar(500) COLLATE utf8_bin NOT NULL, "+
            		"  `SearchRound` int(11) NOT NULL, "+
            		"  `VideosCount` int(11) DEFAULT NULL, "+
            		"  `TimeInMinutes` int(11) DEFAULT NULL, "+
            		"  `ServiceExecutionCount` int(11) DEFAULT NULL, "+
            		"  `VideosReturnedByService` int(11) DEFAULT NULL, "+
            		"  `tablepostfix` varchar(500) NOT NULL "+
            		" ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin";           	
            statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return "uTubeSearchRound created successfully.";
	}
	private static String create_uTubeVideoComments_Table(){		
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement();  
            String createTableCommand =
            		" CREATE TABLE `utubevideocomments` ( "+
            		"  `ID` varchar(60) CHARACTER SET utf8 NOT NULL, "+
            		"  `VideoID` varchar(45) CHARACTER SET utf8 DEFAULT NULL, "+
            		"  `Author` varchar(150) CHARACTER SET utf8 DEFAULT NULL, "+
            		"  `CreatedOn` varchar(45) CHARACTER SET utf8 DEFAULT NULL, "+
            		"  `Content` text COLLATE utf8_bin, "+
            		"  `VideoTitle` varchar(200) CHARACTER SET utf8 DEFAULT NULL, "+
            		"  `VideoAuthor` varchar(150) CHARACTER SET utf8 DEFAULT NULL, "+
            		"  PRIMARY KEY (`ID`), "+
            		"  FULLTEXT KEY `VideoID_Index` (`VideoID`), "+
            		"  FULLTEXT KEY `CommentAuthor_Index` (`Author`), "+
            		"  FULLTEXT KEY `CommentContent_Index` (`Content`) "+
            		" ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin";            	
            statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return "uTubeVideoComments created successfully.";
	}
	private static String create_CommentAuthorsProfile_Table(){
		int result = 0;
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement();  
            String createTableCommand =
            "CREATE TABLE `commentauthorsprofile` ( "+
			" `Author` varchar(150) NOT NULL, "+
			" `CommentsCount` int(11) DEFAULT NULL, "+
			" `AllVideosCount` int(11) DEFAULT NULL, "+
			" `OthersVideosCount` int(11) DEFAULT NULL, "+
			"  PRIMARY KEY (`Author`) "+
			" ) ENGINE=InnoDB DEFAULT CHARSET=utf8";            	
            result = statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return "CommentAuthorsProfile created successfully.";
	}
	private static String create_CommentVideoAuthors_MDVA_Table(){
		int result = 0;
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement();  
            String createTableCommand =
            		"CREATE TABLE `commentvideoauthors_mdva` ( "+
            				"`CommentAuthor` varchar(150) DEFAULT NULL, " +
            				"`CommentedVideosCount` int(11) DEFAULT NULL, " +
            				"`VideoAuthor` varchar(150) DEFAULT NULL, " +
            				"`UploadedVideosCount` int(11) DEFAULT NULL, " +
            				"`TotalRecievedCommentCount` int(11) DEFAULT NULL, " +
            				"`VideosCountRcvngComntFromCommentAuthor` int(11) DEFAULT NULL " +
            				") ENGINE=InnoDB DEFAULT CHARSET=utf8";            	
            result = statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return "CommentAuthorsProfile created successfully.";
	}
	public static String create_uTubeVideos_Table(String table_postfix){
		int result = 0;
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement(); 
           // JOptionPane.showMessageDialog(null, "CREATE TABLE `utubevideos_"+table_postfix+"` ( ");
            String createTableCommand =
            		"CREATE TABLE `utubevideos_"+table_postfix+"` ( "+
            		" `Author` varchar(150) DEFAULT NULL, "+
            		" `Category` varchar(45) DEFAULT NULL, "+
            		"  `CommentsCount` int(11) DEFAULT NULL, "+
            		"  `CreatedOn` datetime DEFAULT NULL, "+
            		"  `Description` varchar(600) DEFAULT NULL, "+
            		"  `DescriptionXed` varchar(600) DEFAULT NULL, "+
            		"  `Dislikes` int(11) DEFAULT NULL, "+
            		"  `Duration` varchar(50) DEFAULT NULL, "+
            		"  `DL_TimeStamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP, "+
            		"  `FavoritesCount` int(11) DEFAULT NULL, "+
            		"  `ID` varchar(50) NOT NULL, "+
            		"  `Likes` int(11) DEFAULT NULL, "+
            		"  `Location` varchar(100) DEFAULT NULL, "+
            		"  `Rating` float DEFAULT NULL, "+
            		"  `QueryString` varchar(200) DEFAULT NULL, "+
            		"  `QueryUrl` varchar(500) DEFAULT NULL, "+
            		"  `QueryFullText` varchar(200) DEFAULT NULL, "+
            		"  `Title` varchar(200) DEFAULT NULL, "+
            		"  `ViewsCount` bigint(20) DEFAULT NULL, "+
            		"  `SearchRound` int(11) DEFAULT NULL, "+
            		"  PRIMARY KEY (`ID`), "+
            		"  FULLTEXT KEY `Title` (`Title`) "+
            		" ) ENGINE=MyISAM DEFAULT CHARSET=utf8";            	
            result = statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return "uTubeVideos created successfully.";
	}
	public static String createUoD_Table(String tableName){
		int result = 0;
		try {
            Connection connection = getDBConnection();            
            Statement statement = connection.createStatement();  
            String createTableCommand =				
    				"CREATE TABLE "+tableName+" ( " +
    				"`Word` varchar(100) NOT NULL, "+				
    				"`WordCount` int(11) DEFAULT NULL, "+
    				"`AuthorsCount` int(11) DEFAULT NULL, "+
    				"`CoWord` varchar(45) DEFAULT NULL, "+
    				"`CoWordAuthorsCount` int(11) DEFAULT NULL, "+
    				"`CoOccurenceCount` int(11) DEFAULT NULL, "+
    				"`CoWordCount` int(11) DEFAULT NULL, "+
    				"`isQueryWord` bit(1) DEFAULT b'0' "+
    				") ENGINE=InnoDB DEFAULT CHARSET=utf8";            	
            result = statement.executeUpdate(createTableCommand);            
        } catch (SQLException e) { 
            e.printStackTrace();
            return e.getMessage();
        } catch (ClassNotFoundException e) { 
			e.printStackTrace();
			return e.getMessage();
		}		
		return tableName + " created successfully.";
	}
	/* This function is to be used by discoverUoD_Word(). 130409 
	 * */
	private ArrayList<ContentItem> fetchDataFromDB(String strContentColNames[], String strSqlQuery){
		String strCols = "";
		ArrayList<ContentItem> contentList = new ArrayList<ContentItem>();
		for (int i = 0 ; i < strContentColNames.length; i ++){
			strCols += strContentColNames[i] +", ";			
		}
		strCols = strCols.substring(0, strCols.lastIndexOf(",")); // Remove Last Comma ,
		try {
			Connection conn = getDBConnection();
			Statement selectDataQuery = conn.createStatement();			
			ResultSet selectDataQueryResultSet = selectDataQuery.executeQuery(strSqlQuery);			
			while(selectDataQueryResultSet.next()){
				ContentItem contentItem = new ContentItem();
				// Append values to the content
				for (int i = 0 ; i < strContentColNames.length; i ++){
					contentItem.setContent(contentItem.getContent() + ", "+selectDataQueryResultSet.getString(strContentColNames[i]));					
				}				
				contentItem.setAuthor(selectDataQueryResultSet.getString("Author"));
				contentList.add(contentItem);
			}						
			conn.close();
			return contentList;
		} catch (SQLException e) {
			harvis.textAreaUodOutput.setText(e.getMessage());
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			harvis.textAreaUodOutput.setText(e.getMessage());
			e.printStackTrace();
		}		
		return null;		
	}
	/* This function primarily works in cooperation with 
	 * uTubeCrawler to ensure that same videos are 
	 * not being accumulated in the videosDataMap. 130409
	 * */
	public HashMap<String, uTubeVideoData> reLoadVideoDataLite(String tablePostFix){
		videoDataMap = new HashMap<String, uTubeVideoData>();		
		try {
			Connection conn = getDBConnection();
			Statement selectVideoDataQuery = conn.createStatement();
			//JOptionPane.showMessageDialog(null, "Select ID, Title, Description, Author, SearchRound from uTubeVideos_"+tablePostFix+" ORDER BY SearchRound DESC");
			
			ResultSet selectVideoDataQueryResultSet = selectVideoDataQuery.executeQuery(
				"Select ID, Title, Description, Author, SearchRound from uTubeVideos_"+tablePostFix+" ORDER BY SearchRound DESC");
			int videoCount = 0;
			while(selectVideoDataQueryResultSet.next()){
	        	uTubeVideoData videoData = new uTubeVideoData();
				videoData.setVideoID(selectVideoDataQueryResultSet.getString("ID"));				// VideoID				
				videoData.setTitle(selectVideoDataQueryResultSet.getString("Title"));	 			// Title
	        	videoData.setDescription(selectVideoDataQueryResultSet.getString("Description"));	// Description
	        	videoData.setAuthor(selectVideoDataQueryResultSet.getString("Author")); 			// Author
	        	videoData.setSearchRound(selectVideoDataQueryResultSet.getInt("SearchRound")); 		// SearchRound
				videoData.setSaved();
				videoDataMap.put(videoData.getVideoID(), videoData);				
				videoCount++;
			}
			harvis.textAreaClient.append("\n\t " + videoCount + " videos loaded into memory.");			
			conn.close();
			return videoDataMap;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return null;
	}
	public int getCoOccurenceCount(Word wordObj, Word coWordObj){
		try {
			Connection conn = getDBConnection();
			Statement selectCoWordQuery = conn.createStatement();
			String strSqlCommand = "";	
			int coOccurrenceCount = 0;
			if (d2iGUI.srcTableName.equals("utubevideocomments")){				
				strSqlCommand =	"SELECT COUNT(Content) AS CoOccurrenceCount "+
						"FROM utubevideocomments "+
						// Put spaces around the strWord to find only complete words
						// It will restrict counting Titles containing strWord mixed into other words (warrior <--> war)
						"WHERE Content LIKE CONCAT('%"+ wordObj.word + "%') AND "+
						"Content LIKE CONCAT('%"+ coWordObj.word + "%')";	
				ResultSet selectCoWordQueryResultSet = selectCoWordQuery.executeQuery(strSqlCommand);				
				while(selectCoWordQueryResultSet.next()){
					coOccurrenceCount = selectCoWordQueryResultSet.getInt("CoOccurrenceCount"); 		// SearchRound				
				}				
			}else if(d2iGUI.srcTableName.equals("utubevideos")){
				strSqlCommand =	"SELECT COUNT(Title) AS CoOccurrenceCount "+
						"FROM utubevideos "+
						// Put spaces around the strWord to find only complete words
						// It will restrict counting Titles containing strWord mixed into other words (warrior <--> war)
						"WHERE Title LIKE CONCAT('%"+ wordObj.word + "%') AND "+
						"Title LIKE CONCAT('%"+ coWordObj.word + "%');";				
				ResultSet selectCoWordQueryResultSet = selectCoWordQuery.executeQuery(strSqlCommand);			
				while(selectCoWordQueryResultSet.next()){
					coOccurrenceCount = selectCoWordQueryResultSet.getInt("CoOccurrenceCount"); 		// SearchRound				
				}
				strSqlCommand =	"SELECT COUNT(Title) AS CoOccurrenceCount "+
						"FROM utubevideos "+
						// Put spaces around the strWord to find only complete words
						// It will restrict counting Titles containing strWord mixed into other words (warrior <--> war)
						"WHERE Description LIKE CONCAT('%"+ wordObj.word + "%') AND "+
						"Description LIKE CONCAT('%"+ coWordObj.word + "%')";
				selectCoWordQueryResultSet = selectCoWordQuery.executeQuery(strSqlCommand);				
				while(selectCoWordQueryResultSet.next()){
					coOccurrenceCount += selectCoWordQueryResultSet.getInt("CoOccurrenceCount"); 		// SearchRound				
				}
			}
			conn.close();
			return coOccurrenceCount;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return 0;
	}
	public int getMaxSearchRound(String queryString){		
		int searchRound = 0;
		try {
			Connection conn = getDBConnection();
			Statement selectMaxSearchRoundQuery = conn.createStatement();
			ResultSet selectMaxSearchRoundResultSet = selectMaxSearchRoundQuery.executeQuery(
					"Select MAX(SearchRound) AS MaxSearchRound from utubesearchround WHERE SeedQueryString LIKE '" + queryString  +"'");			
			while(selectMaxSearchRoundResultSet.next()){
				searchRound = selectMaxSearchRoundResultSet.getInt("MaxSearchRound"); 		// SearchRound				
			}						
			conn.close();
			return searchRound;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return 0;
	}
	public HashMap<String, uTubeQuery> reloadQueryObjects(String queryString,String tablePostFix){
		int searchRound = getMaxSearchRound(queryString);
		try {
			Connection conn = getDBConnection();			
			Statement selectQueryURLQuery = conn.createStatement();
			ResultSet selectQueryResultSet = selectQueryURLQuery.executeQuery(
					" SELECT QueryString, QueryURL, MAX(SearchRound) AS MaxSearchRound " +
					" FROM utubevideos_"+tablePostFix+
					" WHERE QueryString LIKE '%" + queryString +"%' " +
					" GROUP BY QueryString");
			int queryCount = 0;
			HashMap<String, uTubeQuery> queryObjects = new HashMap<String, uTubeQuery>();
			
			while(selectQueryResultSet.next()){
				queryString = selectQueryResultSet.getString("QueryString");
				String queryURL = selectQueryResultSet.getString("QueryURL");
				uTubeQuery checkedQuery = new uTubeQuery(new URL(queryURL));			
				checkedQuery.setQueryString(queryString);				
				checkedQuery.setFullTextQuery(queryString);
				checkedQuery.setChecked();
				checkedQuery.setMaxResults(50);
				checkedQuery.setSearchRound(searchRound);//(selectQueryResultSet.getInt("MaxSearchRound"));
				queryObjects.put(queryString, checkedQuery);				
				queryCount++;
			}
			harvis.textAreaClient.append("\n\t " + queryCount + " existing queries loaded into memory for keyword/s " + queryString);			
			conn.close();			
			return queryObjects;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}
	public HashMap<String, uTubeQuery> reloadQueryObjects(){		
		try {
			Connection conn = getDBConnection();			
			Statement selectQueryURLQuery = conn.createStatement();
			ResultSet selectQueryResultSet = selectQueryURLQuery.executeQuery(
					"SELECT QueryString, QueryURL, MAX(SearchRound) AS MaxSearchRound FROM utubevideos "+					
					"GROUP BY QueryString");
			int queryCount = 0;
			HashMap<String, uTubeQuery> queryObjects = new HashMap<String, uTubeQuery>();
			
			while(selectQueryResultSet.next()){
				String queryString = selectQueryResultSet.getString("QueryString");
				String queryURL = selectQueryResultSet.getString("QueryURL");
				uTubeQuery checkedQuery = new uTubeQuery(new URL(queryURL));			
				checkedQuery.setQueryString(queryString);				
				checkedQuery.setFullTextQuery(queryString);
				checkedQuery.setChecked();
				checkedQuery.setMaxResults(50);
				checkedQuery.setSearchRound(0);//(selectQueryResultSet.getInt("MaxSearchRound"));
				queryObjects.put(queryString, checkedQuery);				
				queryCount++;
			}
			harvis.textAreaClient.append("\n\t " + queryCount + " existing queries loaded into memory.");			
			conn.close();			
			return queryObjects;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}
	public HashMap<String, SearchRound> reloadQueryStrings(){		
		try {
			Connection conn = getDBConnection();			
			Statement selectQueryURLQuery = conn.createStatement();
			ResultSet selectQueryResultSet = selectQueryURLQuery.executeQuery(
					"SELECT SeedQueryString, MAX(SearchRound) AS MaxSearchRound,tablepostfix FROM utubesearchround "+			
					"GROUP BY SeedQueryString");			
			HashMap<String, SearchRound> queryObjects = new HashMap<String, SearchRound>();
			
			while(selectQueryResultSet.next()){
				String fullQueryString = selectQueryResultSet.getString("SeedQueryString");
//				String queryString = fullQueryString.substring(1, fullQueryString.indexOf('"', 1));
//				if (queryObjects.containsKey(queryString) == false)
//					queryObjects.put(queryString, fullQueryString);
				fullQueryString = fullQueryString.replaceAll("\"", "");
				String tablePostfix = selectQueryResultSet.getString("tablepostfix");
				queryObjects.put(fullQueryString, new SearchRound(fullQueryString,tablePostfix));
				
			}
			
			conn.close();			
			return queryObjects;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}

	public boolean wordsMatchExists(String KeyWords, String titleAndDesc ){	
		BufferedReader mustKeyWordsReader = new BufferedReader(new StringReader(KeyWords));
		String delim = " &\t\n.,:;?!@#$%^&*~+-/{}()[]\"\'1234567890";
		//String text1Line = "";
		String titleAndDescLine = "";		
		String titleAndDescWord;
		boolean matchExists = false;		
		try {
			while((KeyWords = mustKeyWordsReader.readLine()) != null){
				StringTokenizer mustKeyWordsTokenizer = new StringTokenizer(KeyWords, delim); 
				while (mustKeyWordsTokenizer.hasMoreTokens()) {
					String keyWord = mustKeyWordsTokenizer.nextToken().toLowerCase().trim();
					matchExists = false;
					BufferedReader titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
					while ((titleAndDescLine = titleAndDescReader.readLine()) != null){
						StringTokenizer titleAndDescTokenizer = new StringTokenizer(titleAndDescLine, delim);
						while (titleAndDescTokenizer.hasMoreTokens()) {
							titleAndDescWord = titleAndDescTokenizer.nextToken().toLowerCase().trim();
							if (keyWord.length() == titleAndDescWord.length()){								
								matchExists = keyWord.equalsIgnoreCase(titleAndDescWord);
								if (matchExists) {									
									break;			
								}
							}
						}// while titleAndDescTokenizer has more tokens
						if (matchExists)
							break; // Match found, stop finding in remaining words of titleAndDescLine
					} // while titleAndDescLine has a line to be processed	
					titleAndDescReader.close();					
				}				
			}			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return matchExists;
	}
	protected void insertSearchRoundRecordIntoDB(String searchKeyWord,
												String tablePostFix,
												int searchRound, 
												int timeInMinutes, 
												int videosCount,
												int serviceExecutionCount,
												int videosReturnedByService){
		PreparedStatement preparedStatement = null;
		String insertSearchRoundRecord = 
				"INSERT INTO utubesearchround (SeedQueryString, SearchRound, TimeInMinutes, VideosCount, ServiceExecutionCount, VideosReturnedByService,tablepostfix) "+
				"VALUES "+
				"(?,?,?,?,?,?,?)";				
		try {
			Connection conn = getDBConnection();
			preparedStatement = conn.prepareStatement(insertSearchRoundRecord);
			preparedStatement.setString(1, searchKeyWord);
			preparedStatement.setInt(2, searchRound);
			preparedStatement.setInt(3, timeInMinutes);
			preparedStatement.setInt(4, videosCount);
			preparedStatement.setInt(5, serviceExecutionCount);
			preparedStatement.setInt(6, videosReturnedByService);	
			preparedStatement.setString(7, tablePostFix);
			preparedStatement.executeUpdate();			
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void insertUoD_Word_IntoDB(Word wordObj, Word coWordObj, int coOccurenceCount){
		PreparedStatement preparedStatement = null;
		String insertSearchRoundRecord = 
				"INSERT INTO "+ d2iGUI.destTableName + " (Word, WordCount, AuthorsCount, CoWord, CoWordCount,CoWordAuthorsCount, CoOccurenceCount, isQueryWord) "+
				"VALUES "+
				"(?,?,?,?,?,?,?,?)";				
		try {
			Connection conn = getDBConnection();
			
			preparedStatement = conn.prepareStatement(insertSearchRoundRecord);
			preparedStatement.setString	(1, wordObj.word);
			preparedStatement.setInt	(2, wordObj.wordCount);
			preparedStatement.setInt	(3, wordObj.authorCount);
			preparedStatement.setString	(4, coWordObj.word);
			preparedStatement.setInt	(5, coWordObj.wordCount);
			preparedStatement.setInt	(6, coWordObj.authorCount);
			preparedStatement.setInt	(7, coOccurenceCount);
			preparedStatement.setBoolean(8, wordObj.isQueryKeyWord);
			
			preparedStatement.executeUpdate();
			
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void insertVideoCommentsIntoDB(uTubeVideoData videoData){
		uTubeVideoComment comment = null;
		PreparedStatement preparedStatement = null;
		String insertVideoCommentsSQL = 
				"INSERT INTO uTubeVideoComments " + 
				"(Author, Content, CreatedOn, ID, VideoID, VideoTitle, VideoAuthor) VALUES " +
				"(?,?,?,?,?,?,?)";		
		
		try {
			preparedStatement = dbConnection.prepareStatement(insertVideoCommentsSQL);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int commentCount = 1;
		Iterator<uTubeVideoComment> commentsIter = videoData.comments.iterator();
		for(; commentsIter.hasNext() ; ){								
				comment = commentsIter.next();
				try{
					preparedStatement.setString(1, 	comment.getAuthor());
					preparedStatement.setString(2, 	comment.getContent().replaceAll("[^\\u0000-\\uFFFF]", ""));
					preparedStatement.setDate(	3, 	comment.getCreatedOn());
					preparedStatement.setString(4,	videoData.getVideoID()+" Comment " + commentCount++);
					preparedStatement.setString(5,	videoData.getVideoID());
					preparedStatement.setString(6,	videoData.getTitle());
					preparedStatement.setString(7,	videoData.getAuthor());
					
				
					preparedStatement.executeUpdate();
				}catch(SQLException e){
					e.printStackTrace();
					System.out.println(comment.getContent());					
				}
		}		
	}
	private void insertVideoRecordIntoDB(uTubeVideoData videoData)  {		
		PreparedStatement preparedStatement = null; 
		String postFix=videoData.getQueryObject().getTableNamePostFix();
		String insertVideoDataSQL = 
		"INSERT INTO uTubeVideos_"+postFix + 
		"(Author, Category, CommentsCount, CreatedOn, Description, Dislikes, Duration, " +
		"FavoritesCount, ID, DL_TimeStamp, Likes, Location, Rating, QueryString, QueryUrl, QueryFullText, " +
		"Title, ViewsCount, SearchRound) VALUES " +
		"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";		
		try {			
			preparedStatement = dbConnection.prepareStatement(insertVideoDataSQL); 
			preparedStatement.setString(1, videoData.getAuthor()); 											//Author
			preparedStatement.setString(2, videoData.getCategory());										//Category
			preparedStatement.setInt(3, videoData.getCommentsCount());										//CommentsCount
			preparedStatement.setDate(4, videoData.getCreatedOn());											//CreatedOn 
			preparedStatement.setString(5, videoData.getDescription().replaceAll("[^\\u0000-\\uFFFF]", ""));//Description
			preparedStatement.setInt(6, videoData.getDislikesCount()); 										//Dislikes
			preparedStatement.setString(7, videoData.getDuration()); 										//Duration
			preparedStatement.setLong(8, videoData.getFavoriteCount());										//FavoritesCount
			preparedStatement.setString(9,videoData.getVideoID()); 											// ID
			preparedStatement.setTimestamp(10, null);														// TimeStamp
			preparedStatement.setInt(11, videoData.getLikesCount()); 										//Likes
			preparedStatement.setString(12, videoData.getLocation()); 										//Location
			preparedStatement.setFloat(13, videoData.getRating()); 											//Rating			
			preparedStatement.setString(14, videoData.getQueryObject().getQueryString()); 					// QueryString			
			preparedStatement.setString(15, videoData.getQueryObject().getFullUrl() + ""); 					// QueryUrl
			preparedStatement.setString(16, videoData.getQueryObject().getFullTextQuery());					// FullTextQuery
			preparedStatement.setString(17, videoData.getTitle().replaceAll("[^\\u0000-\\uFFFF]", ""));		//Title
			preparedStatement.setLong(18, videoData.getViewCount());										//ViewsCount
			preparedStatement.setLong(19, videoData.getSearchRound());										//SearchRound
			

			preparedStatement.executeUpdate();
			
			videoData.setSaved();
			// harvis.textAreaDM.append("\n\t uTubeDM: Data for video " + videoData.getTitle() + " saved.");
			// Save Comments
			insertVideoCommentsIntoDB(videoData);
		}catch(com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException e){
			harvis.textAreaDM.append("\n\t uTubeDM: IntegrityConstraint Exception \n\t" + videoData.getVideoID() + " already inserted");
			e.printStackTrace();							 
		}catch (SQLException e) { 
			harvis.textAreaDM.append("\n\t uTubeDM: SQL Exception " + e.getMessage());			
			e.printStackTrace(); 
		}
		finally { 
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		} 
	}
	public static void setDBConnParameters(String dbUserName, String dbPwd, String dbUrl, String dbSchemaName){
		dbUser = dbUserName;
		dbPassword = dbPwd;
		dbURL = dbUrl;
		dbSchema = dbSchemaName;
	}
	/* This method is to be used by 
	 * 
	 * */
	public static void setDBConnParameters(String dbUserName, String dbPwd, String dbUrl){
		dbUser = dbUserName;
		dbPassword = dbPwd;
		dbURL = dbUrl;
	}
	public static String getDbUser() {
		return dbUser;
	}
	public static String getDbPassword() {
		return dbPassword;
	}
	public static String getDbURL() {
		return dbURL;
	}
	public static String getDbSchemaName() {
		return dbSchema;
	}
}

