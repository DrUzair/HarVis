package yt.har;

import java.util.ArrayList;
import java.util.HashMap;

public class uTubeCommentAuthor {
	private int nVideosCommented = 0;
	private String authorID = "";	
	public uTubeCommentAuthor(String id){
		authorID = id;
		commentsMap = new HashMap<String, ArrayList<uTubeVideoComment>>();
	}
	public int getVideosCommented() {
		return nVideosCommented;
	}
	public void setVideosCommented(int nVideosCommented) {
		this.nVideosCommented = nVideosCommented;
	}
	public String getAuthorID() {
		return authorID;
	}
	public HashMap<String, ArrayList<uTubeVideoComment>> commentsMap;
}
