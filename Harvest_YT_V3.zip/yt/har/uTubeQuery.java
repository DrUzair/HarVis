package yt.har;
import java.net.URL;
import java.util.List;

import com.google.gdata.client.Query;
import com.google.gdata.client.youtube.YouTubeQuery;
public class uTubeQuery extends YouTubeQuery{
	private String queryString;
	private String tableNamePostFix;
	public String getTableNamePostFix() {
		return tableNamePostFix;
	}
	public void setTableNamePostFix(String tableNamePostFix) {
		this.tableNamePostFix = tableNamePostFix;
	}
	private boolean checked;
	protected boolean isChecked(){return checked;}
	protected void setChecked(){checked = true;}
	private int searchRound = 0;
	
	public int getSearchRound() {
		return searchRound;
	}
	public void setSearchRound(int searchRound) {
		this.searchRound = searchRound;
	}
	public String getQueryString(){
		return queryString;
	}
	public void setQueryString(String strQuery){
		queryString = strQuery;
	}
	
	public uTubeQuery(URL url){
		super(url);	
	} 
	
	public boolean equals(Object query){
		String queryString = ((uTubeQuery)query).getUrl().toString();
		String existingQuryString = this.getUrl().toString();
		if(queryString.equalsIgnoreCase(existingQuryString))
			return true;		
		else
			return false;		
	}
	public String getFullUrl(){
		//List<Query.CategoryFilter> cats = this.getCategoryFilters();
		URL url = this.getUrl();
		String urlString = url.getProtocol() +"://" + url.getHost() + url.getPath() +"?" +url.getQuery() + "&v=2" ;
		//System.out.println(urlString);
		return urlString;
	}
}
