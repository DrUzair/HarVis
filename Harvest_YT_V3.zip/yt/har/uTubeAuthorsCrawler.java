package yt.har;

import java.io.IOException;
import java.net.URL;
import java.util.Set;

import com.google.gdata.client.youtube.YouTubeService;
import com.google.gdata.data.youtube.UserProfileEntry;
import com.google.gdata.data.youtube.UserProfileFeed;
import com.google.gdata.data.youtube.YtUserProfileStatistics;
import com.google.gdata.util.ServiceException;

public class uTubeAuthorsCrawler {
	protected static YouTubeService service;	
	private String developerKey = "AI39si6Vi8lLyuPXuqBTT0iDsGuhvcayuccp6L16xV5um8VT5dAR7B3-I6LDDxuErg0S8D1XdiIbg3GeatcRWfu2SgkRdPJ0gQ";
	public uTubeAuthorsCrawler() {
		service = new YouTubeService("uTubeMatrix", developerKey);
	}
	
	public void startCrawling(){
		try {
			showActivity();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/** * Shows a user's activity feed. * * 
	 * @param service a YouTubeService object. * 
	 * @throws 
	 * IOException Error sending request or reading the feed. * 
	 * @throws ServiceException If the service is unable to handle the request. */
	private static void showActivity() throws IOException,    ServiceException {  
		String users = "ActionYaDawry";  
		String feed = "http://gdata.youtube.com/feeds/api/events?author=";  
		printActivityFeed(service, feed + users);}
	/** * Fetches a feed of activities and prints information about them. 
	 * * * @param service An authenticated YouTubeService object 
	 * * @param feedUrl The url of the activity feed to print. 
	 * * @throws IOException Error sending request or reading the feed. 
	 * * @throws ServiceException If the service is unable to handle the request. */
	@SuppressWarnings("deprecation")
	private static void printActivityFeed(YouTubeService service, String profileUrl)    throws IOException, ServiceException {  
		UserProfileFeed userProfileFeed = service.getFeed(new URL(profileUrl), UserProfileFeed.class);  
		
		String title = userProfileFeed.getTitle().getPlainText();  
		
		
		if (userProfileFeed.getEntries().size() == 0) {    
			System.out.println("This feed contains no entries.");    
			return;  
		}
		
		for (UserProfileEntry profileEntry : userProfileFeed.getEntries()){
				if( profileEntry.getExtensions().isEmpty())
					System.out.println("no extensions");

				Set<com.google.gdata.data.Category> set = profileEntry.getCategories();
				
		}
		
		profileUrl = "http://gdata.youtube.com/feeds/api/users/battakh";

		UserProfileEntry profileEntry = service.getEntry(new URL(profileUrl), UserProfileEntry.class);

		 
			System.out.println("Username: " + profileEntry.getUsername());
			System.out.println("Age     : " + profileEntry.getAge());
			System.out.println("Gender  : " + profileEntry.getGender());
			System.out.println("Single? : " + profileEntry.getRelationship());
			System.out.println("Books   : " + profileEntry.getBooks());
			System.out.println("Company : " + profileEntry.getCompany());
		//	System.out.println("Description: " + profileEntry.g());
			System.out.println("Hobbies : " + profileEntry.getHobbies());
			System.out.println("Hometown: " + profileEntry.getHometown());
			System.out.println("Location: " + profileEntry.getLocation());
			System.out.println("Movies  : " + profileEntry.getMovies());
			System.out.println("Music   : " + profileEntry.getMusic());
			System.out.println("Job     : " + profileEntry.getOccupation());
			System.out.println("School  : " + profileEntry.getSchool());
			
			YtUserProfileStatistics stats = profileEntry.getStatistics();
		    
			if(stats != null) {
			  System.out.println("Subscriber count: " + stats.getSubscriberCount());
			  System.out.println("Last web access: " + stats.getLastWebAccess().toUiString());
			}	
	}
}
