package yt.har;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import searchvideo.v3.VedioV3Feed;
import searchvideo.v3.VideoEntry;
import searchvideo.v3.VideoNotFoundException;






import yt.HarVisEx;
import yt.YouTubeHerVester;

import com.google.gdata.client.youtube.YouTubeService;
import com.google.gdata.data.DateTime;
import com.google.gdata.data.Entry;
import com.google.gdata.data.Feed;
import com.google.gdata.data.Person;
import com.google.gdata.data.TextConstruct;
import com.google.gdata.data.TextContent;
import com.google.gdata.data.extensions.Comments;
import com.google.gdata.data.extensions.Rating;
import com.google.gdata.data.media.mediarss.MediaCategory;
import com.google.gdata.data.youtube.VideoFeed;
import com.google.gdata.data.youtube.YouTubeMediaGroup;
import com.google.gdata.data.youtube.YtRating;
//import com.google.gdata.client.youtube.YouTubeQuery;

public class YouTubeCrawler implements Runnable{	
	private static final String YOUTUBE_URL = "http://gdata.youtube.com/feeds/api/videos"; 
	private int SEARCH_ROUND = 1;
	private int SERVICE_EXECUTION_COUNT = 0;
	private String words_2b_filtered = "";
	protected HashMap<String, HashMap<String, uTubeQuery>> queryStringsMap;
	private Map<String, String> uniqueKeyWordsMap;
	//protected HashMap<String, uTubeQuery> evovledQueryObjects;
	protected static YouTubeService service;	
	private Map<String, uTubeVideoData> videoDataMap;
	private List<String> existVedioIDList;
	//private String developerKey = "AI39si6Vi8lLyuPXuqBTT0iDsGuhvcayuccp6L16xV5um8VT5dAR7B3-I6LDDxuErg0S8D1XdiIbg3GeatcRWfu2SgkRdPJ0gQ";
	String API_KEY="AIzaSyBR34U7D3T8lKVBc2DmV8V9R3dWvcr2EzA";
	private YouTubeHerVester harvis;
	// private uTubeClientThreadsManager threadManager;
	private int videoCount;		
	private int maxResults;
	private boolean relaxSelectionCriteria = true;
	
	public void setRelaxSelectionCriteria(boolean relaxSelectionCriteria) {
		this.relaxSelectionCriteria = relaxSelectionCriteria;
	}

	// CONSTRUCTOR FOR NEW CAMPAIGN MODE
	public YouTubeCrawler(HashMap<String, HashMap<String, uTubeQuery>> queryStringsMap,						  					  
						  int maxReslts, 
						  YouTubeHerVester harvis,
						  String userID,
						  String userKey){				
		videoCount = 0 ;
		maxResults = maxReslts;
		videoDataMap = new HashMap<String, uTubeVideoData>();
		service = new YouTubeService(userID, userKey);
		this.harvis = harvis;				
		this.queryStringsMap = queryStringsMap;
	}
	
	// CONSTRUCTOR FOR RESUME CAMPAIGN MODE
	public YouTubeCrawler(HashMap<String, HashMap<String, uTubeQuery>> queryStringsMap,
			Map<String, uTubeVideoData> existingVideosDataMap,
			int maxReslts,
			YouTubeHerVester harvis,
			String userID,
			String userKey){		
		this.queryStringsMap = queryStringsMap;			
		videoCount = existingVideosDataMap.size();
		maxResults = maxReslts;		
		videoDataMap = existingVideosDataMap;
		service = new YouTubeService(userID, userKey);
		this.harvis = harvis;
		existVedioIDList=new ArrayList<String>();
		for (Map.Entry<String, uTubeVideoData> entry : existingVideosDataMap.entrySet()) {
			existVedioIDList.add(entry.getKey());
		}
	}
	
	private void loadFilterWords(){
		URL fileURL = HarVisEx.class.getResource("Resources/word_2b_filtered");
		words_2b_filtered = "";
		try {
			System.out.println(fileURL.getFile());
			FileReader fr = new FileReader(fileURL.getFile());
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			words_2b_filtered += line;
			while(line != null){
				System.out.println(line);
				line = br.readLine();
				words_2b_filtered += line;
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	public void setSearchRound(int i ){
		SEARCH_ROUND = i;
	}
	// MUST BE CALLED AFTER ascertaining videoExistsInCollection
	private void addVideoData2Collection(uTubeVideoData videoData){		
		videoDataMap.put(videoData.getVideoID(), videoData);
		videoCount++;		 
	}
	private boolean videoExistsInCollection(String videoID){		
		boolean videoExists = videoDataMap.containsKey(videoID); 
		if (videoExists)
			return true;
		return false;
	}
	private int getVideoCount(){return videoCount;}
	private String getFirstCategory(VideoEntry e) {
        YouTubeMediaGroup mg = e.getMediaGroup();
        MediaCategory fcat=null;
        try{
        fcat = mg.getCategories() != null && mg.getCategories().size() > 0 ? mg.getCategories().get(0) : null;
        }
        catch(Exception ex){}
        return fcat != null? fcat.getLabel(): "-";
    }
	private uTubeVideoData captureVideoData( VideoEntry oneVideo, uTubeQuery query){       	      	
        	uTubeVideoData videoData = new uTubeVideoData();    
        	String trimmedID = oneVideo.getId();        	
        	//System.out.println(oneVideo.getId() + " Trimmed to "+ trimmedID);
            videoData.setVideoID(trimmedID); 											// ID
            DateTime dateTime =oneVideo.getPublished();
            videoData.setCreatedOn(new java.sql.Date(dateTime.getValue())); 			// CreatedOn
            TextConstruct oneVideoTitle = oneVideo.getTitle();
            String title = oneVideoTitle.getPlainText();
            title.replace('"', ' '); 
         // This is to make data readable from CSV, see VideoLifeSpanProfile
            title.replace(',', ' '); 
         // This is to make data readable from CSV, see VideoLifeSpanProfile
            videoData.setTitle(title);													// Title

         //  YouTubeMediaGroup mediaGroup = oneVideo.getMediaGroup();

            //System.out.println("Uploaded by: " + mediaGroup.getUploader());
            String description = oneVideo.getDescription();
            if (description.length() > 600) 
            	// Description field in uTubeVideos table is Varchar(600)
            	description = description.substring(0, 599);
            videoData.setDescription(description);										// Description


            List<Person> allAuthors = oneVideo.getAuthors();
            Iterator<Person> itAllAuthors = allAuthors.iterator();
            while (itAllAuthors.hasNext()){
                Person oneAuthor = itAllAuthors.next();               
                videoData.setAuthor(oneAuthor.getName());                				// Author         
                videoData.setAuthorEmail(oneAuthor.getEmail());							// Email
                videoData.setAuthorUri(oneAuthor.getUri());								// Uri
                videoData.setAuthorLanguage(oneAuthor.getNameLang());					// Name Language                
            }            
            videoData.setLocation(oneVideo.getLocation());								// Location
            videoData.setCategory(oneVideo.getCategory());							// Category
            if (oneVideo.getStatistics() != null){            	
            	videoData.setViewCount(oneVideo.getStatistics().getViewCount());		// ViewsCount
            	videoData.setFavoriteCount(oneVideo.getStatistics().getFavoriteCount());// FavoritesCount
            }
            else{
            	videoData.setViewCount(0);
            	videoData.setFavoriteCount(0);
            }
             
            //Related Videos Feed Url
            if (oneVideo.getRelatedVideosLink() != null) {
            	  videoData.setRelatedVideosFeedUrl(oneVideo.getRelatedVideosLink());           	  
            }else{
            	videoData.setRelatedVideosFeedUrl(null);
            }
            // Comments
            Comments comments = oneVideo.getComments();
            int commentsCount = 0;
            if (oneVideo.getComments() != null && oneVideo.getComments().getFeedLink() != null){            	
            	commentsCount = comments.getFeedLink().getCountHint();
            	String feedLink = comments.getFeedLink().getHref();            	
            	int startIndex = 1;
            	int entriesReturned = 0; 
            	String startIndexStr = "&start-index="+startIndex;
            	        		            		
            		while(true){		            		            	
            			boolean exceptionOccured = false;
            			try {
	            			Feed feed =null;// oneVideo.getService().getFeed(new URL(feedLink+startIndexStr), Feed.class);
	            			SERVICE_EXECUTION_COUNT++;
			            	entriesReturned = feed.getEntries().size();
			            	if (entriesReturned == 0)
			            		break;		            	
			            	for (Entry e : feed.getEntries()) {
			            		uTubeVideoComment commentObj = new uTubeVideoComment();
			            		commentObj.setvideo(videoData);	            	
			            		if (e.getContent() != null) {
			            			TextContent content = (TextContent) e.getContent();
			            			commentObj.setContent(content.getContent().getPlainText());
			            		}
			            		commentObj.setCreatedOn(new java.sql.Date(e.getUpdated().getValue()));
			            		List<Person> commentAuthors = e.getAuthors();	            			               
			            		Iterator<Person> itCommentAuthors = commentAuthors.iterator();	            		
			            		while (itCommentAuthors.hasNext()){
			            			Person commentAuthor = itCommentAuthors.next();
			            			
			            			//Print authors of current title:
			            			commentObj.setAuthor(commentAuthor.getName());								// Name
			            			commentObj.setAuthorEmail(commentAuthor.getEmail());							// Email
			            			commentObj.setAuthorUri(commentAuthor.getUri());								// Uri
			            			commentObj.setAuthorLanguage(commentAuthor.getNameLang());					// Name Language   
			            		}
	//		            		uTubeClient.textAreaCrawler.append("\n\t CA " + commentObj.getAuthor() + "\n\t" + commentObj.getContent());
			            		videoData.comments.add(commentObj);
			            	}
			            	startIndex = startIndex + entriesReturned;
			            	if (startIndex > 975 | entriesReturned < 25 )
			            		break;		            	
			            	startIndexStr = "&start-index="+startIndex;			            	
            			}catch(Exception e){
            				e.printStackTrace();
            				exceptionOccured = true;
            			}
            			if (exceptionOccured){
            				break;
            			}
            		}            	          		 	            	
            }
            videoData.setCommentsCount(oneVideo.getCommentCount()); 								//Comments Count
            			
            videoData.setDuration(oneVideo.getDuration());			// Duration ??
            Rating gdrating = oneVideo.getRating();
            float avgrating = 0.0F;
            if (gdrating != null)
            	avgrating = gdrating.getAverage();
            videoData.setRating(avgrating); 										// Average Rating
            
            YtRating rating = oneVideo.getYtRating(); 
            int dislikesCount = 0;
            int likesCount = 0;
            if (rating != null){
	            videoData.setDislikesCount(rating.getNumDislikes()); 				// Dislikes
	            videoData.setLikesCount(rating.getNumLikes()); 						// Likes
            }else{
            	videoData.setDislikesCount(dislikesCount); 							// Dislikes
 	            videoData.setLikesCount(likesCount); 								// Likes
            }            
            videoData.setQueryObject(query);  
            videoData.setSearchRound(SEARCH_ROUND);
            return videoData;
	}
//	private HashMap<String, uTubeQuery> evolveQueryByAuthor(String seedQueryString){
//		// Fetch Queries Map for seedQueryString
//		HashMap<String, uTubeQuery> evovledQueryObjects = queryStringsMap.get(seedQueryString);
//		
//		// Get all unique authors from videoDataMap		
//		Set<java.util.Map.Entry<String, uTubeVideoData>> dataSet = videoDataMap.entrySet();							 
//		Iterator<java.util.Map.Entry<String, uTubeVideoData>> videoDataSetIterator = dataSet.iterator();		
//		Map<String, String> authorsMap = new HashMap<String, String>();
//		
//		// Make a Map of authors of videos in videoDataMap
//		while(videoDataSetIterator.hasNext()){
//			Map.Entry<String, uTubeVideoData> entry = (Map.Entry<String, uTubeVideoData>) videoDataSetIterator.next();
//			uTubeVideoData videoData = (uTubeVideoData)entry.getValue();
//			String author  = videoData.getAuthor();
//			String authorKey = authorsMap.get(author);			 
//			if (authorKey == null) 
//				authorsMap.put(author, author);			
//		}		
//		// For each author in the Set Make a new Query object
//		Set<java.util.Map.Entry<String, String>> authorSet = authorsMap.entrySet();
//		Iterator<java.util.Map.Entry<String, String>> authorSetIterator = authorSet.iterator();
//		while(authorSetIterator.hasNext()){			
//			Map.Entry<String, String> entry = (Map.Entry<String, String>) authorSetIterator.next();
//			String author = (String)entry.getValue();			
//			// Create a newQuery object with this author						
//			try{
//				uTubeQuery newQuery = new uTubeQuery(new URL(YOUTUBE_URL));			
//				newQuery.setFullTextQuery(seedQueryString +"+"+author);
//				newQuery.setMaxResults(maxResults);			
//				newQuery.setAuthor(author);
//				newQuery.setQueryString(seedQueryString +" "+author);
//				newQuery.setSearchRound(1);
//				// Check if the evolvedQueryObjects does not already have the query 
//				uTubeQuery existingQuery  = evovledQueryObjects.get(newQuery.getQueryString());	
//				if (existingQuery == null){
//					// Add newQuery to evolvedQueryObjects			
//					evovledQueryObjects.put(newQuery.getQueryString(), newQuery);
//					harvis.textAreaCrawler.append("\n\t New Query " + newQuery.getQueryString());
//					if (harvis.textAreaCrawler.getLineCount() > 500)
//						harvis.textAreaCrawler.setText("");
//				}else{
//					harvis.textAreaCrawler.append("\n\n\t Query Checked: " + newQuery.getQueryString());
//					if (harvis.textAreaCrawler.getLineCount() > 500)
//						harvis.textAreaCrawler.setText("");
//				}
//			}catch(Exception e){				
//				e.printStackTrace();
//			}			
//		}		
//		return evovledQueryObjects;
//	}
//	public boolean wordsMatchExists(String KeyWords, String titleAndDesc, boolean allWordsMustMatch ){
//		BufferedReader mustKeyWordsReader = new BufferedReader(new StringReader(KeyWords));
//		BufferedReader titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
//		String delim = " &\t\n.,:;?!@#$%^&*~+-/{}()[]\"\'1234567890";
//		//String text1Line = "";
//		String titleAndDescLine = "";
//		String keyWord;
//		String titleAndDescWord;
//		boolean matchExists = false;		
////		int keyWordsCount = 0;
//		try {
//			while((KeyWords = mustKeyWordsReader.readLine()) != null){
//				StringTokenizer mustKeyWordsTokenizer = new StringTokenizer(KeyWords, delim); 
//				while (mustKeyWordsTokenizer.hasMoreTokens()) {
////					keyWordsCount++;
//				}				
//			}
//			mustKeyWordsReader.reset();
//		} catch (IOException e1) {
// 
//			e1.printStackTrace();
//		}
//		
////		int matchCount = 0;
//		try {
//			while((KeyWords = mustKeyWordsReader.readLine()) != null){			
//				StringTokenizer mustKeyWordsTokenizer = new StringTokenizer(KeyWords, delim); 
//				while (mustKeyWordsTokenizer.hasMoreTokens()) {
//					keyWord = mustKeyWordsTokenizer.nextToken().toLowerCase().trim(); 
//					while ((titleAndDescLine = titleAndDescReader.readLine()) != null){
//						StringTokenizer titleAndDescTokenizer = new StringTokenizer(titleAndDescLine, delim);
//						while (titleAndDescTokenizer.hasMoreTokens()) {
//							titleAndDescWord = titleAndDescTokenizer.nextToken().toLowerCase().trim();
//							if (keyWord.length() == titleAndDescWord.length()){								
//								matchExists = keyWord.equalsIgnoreCase(titleAndDescWord);
//								if (matchExists) {
////									matchCount ++;
//									break;			
//								}
//							}
//						}// while titleAndDescTokenizer has more tokens
//						if (matchExists)
//							break; // Match found, stop finding in remaining words of titleAndDescLine
//					} // while titleAndDescLine has a line to be processed
//					if (matchExists){
//						if (allWordsMustMatch == false)
//							break;
//						else if (mustKeyWordsTokenizer.hasMoreTokens() == true){
//							titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
//							matchExists = false;	// Only one word match isn't enough. Search for next keyWord Match.
//						}
//					}else if (mustKeyWordsTokenizer.hasMoreTokens() == true){
//						titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
//					}						
// 				}// while st1 has more tokens
//			}// text1Line has a line to be processed
//		} catch (IOException e) {			
//			e.printStackTrace();
//		}
//		return matchExists;
//	}
	public boolean wordsMatchExists(String titleAndDesc, boolean allWordsMustMatch){
		Set<String> keyWordSet = queryStringsMap.keySet();
		boolean matchExists = false;		
		try {			
			Iterator<String> keyWordSetIter = keyWordSet.iterator();
			while(keyWordSetIter.hasNext()){			
					String keyWords = keyWordSetIter.next(); 
					BufferedReader mustKeyWordsReader = new BufferedReader(new StringReader(keyWords));
					BufferedReader titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
					String delim = " =&\t\n.,:;?!@#$%^&*~+-/{}()[]\"\'1234567890";
					//String text1Line = "";
					String titleAndDescLine = "";
					String keyWord;
					String titleAndDescWord;							
//					int keyWordsCount = 0;		
//					int matchCount = 0;					
					while((keyWords = mustKeyWordsReader.readLine()) != null){			
						StringTokenizer mustKeyWordsTokenizer = new StringTokenizer(keyWords, delim); 
						while (mustKeyWordsTokenizer.hasMoreTokens()) {
							keyWord = mustKeyWordsTokenizer.nextToken().toLowerCase().trim();
							matchExists = titleAndDesc.contains(keyWord);							
							while ((titleAndDescLine = titleAndDescReader.readLine()) != null){								
								StringTokenizer titleAndDescTokenizer = new StringTokenizer(titleAndDescLine, delim);
								while (titleAndDescTokenizer.hasMoreTokens()) {
									titleAndDescWord = titleAndDescTokenizer.nextToken().toLowerCase().trim();
									if (relaxSelectionCriteria == true)
										matchExists = keyWord.contains(titleAndDescWord) ? true : titleAndDesc.contains(keyWord);
									else
										matchExists = keyWord.equals(titleAndDescWord);
									if (matchExists) {
//										matchCount ++;
										break;			
									}									
								}// while titleAndDescTokenizer has more tokens
								if (matchExists)
									break; // Match found, stop finding in remaining words of titleAndDescLine
							} // while titleAndDescLine has a line to be processed
							if (matchExists){
								if (allWordsMustMatch == false)
									break;
								else if (mustKeyWordsTokenizer.hasMoreTokens() == true){
									titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
									matchExists = false;	// Only one word match isn't enough. Search for next keyWord Match.
								}
							}else if (mustKeyWordsTokenizer.hasMoreTokens() == true){
								titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
							}						
						}// while mustKeyWordsTokenizer has more tokens
					}// while mustKeyWordsReader has a line to be processed
					if (matchExists) break;
			}// while keyWordSetIter has more keyWords
		} catch (IOException e) {			
				e.printStackTrace();
		}
		return matchExists;
	}
	public float wordsMatchRatio(String titleAndDesc ){	
		String delim = " &\t\n.,:;?!@#$%^&*~+-/{}()[]\"\'1234567890";
		//String text1Line = "";
		String titleAndDescLine = "";		
		String titleAndDescWord;
		boolean matchExists = false;		
		float matchCount = 0.0F;
		Set<String> keyWordSet = queryStringsMap.keySet();
		//Set<String> keyWordSet = uniqueKeyWordsMap.keySet();
		try {			
			Iterator<String> keyWordSetIter = keyWordSet.iterator();
			while(keyWordSetIter.hasNext()){			
					String keyWord = keyWordSetIter.next(); 
					BufferedReader titleAndDescReader = new BufferedReader(new StringReader(titleAndDesc));
					while ((titleAndDescLine = titleAndDescReader.readLine()) != null){
						StringTokenizer titleAndDescTokenizer = new StringTokenizer(titleAndDescLine, delim);
						while (titleAndDescTokenizer.hasMoreTokens()) {
							titleAndDescWord = titleAndDescTokenizer.nextToken().toLowerCase().trim();
							if (keyWord.length() == titleAndDescWord.length()){								
								matchExists = keyWord.equalsIgnoreCase(titleAndDescWord);
								if (matchExists) {
									matchCount ++;
									break;			
								}
							}
						}// while titleAndDescTokenizer has more tokens
						if (matchExists)
							break; // Match found, stop finding in remaining words of titleAndDescLine
					} // while titleAndDescLine has a line to be processed	
					titleAndDescReader.close();
 			}// while more keyWords
		} catch (IOException e) {			
			e.printStackTrace();
		}
		return matchCount;
	}
	
	private HashMap<String, uTubeQuery> evolveQueryByTitles(String seedQueryString, String tableNamePostFix){
		
		// Fetch Queries Map for seedQueryString
		HashMap<String, uTubeQuery> evovledQueryObjects = queryStringsMap.get(seedQueryString);
		
		Set<Map.Entry<String,uTubeVideoData>> dataSet = videoDataMap.entrySet();
		int videosCount = dataSet.size();
		Iterator<Map.Entry<String,uTubeVideoData>> videoDataSetIterator = dataSet.iterator();
		
		// Fetch Video Titles from the videoDataMap and build wordsMap
		int titleNumber = 0;		
		Map<String, Word> wordsMap = new HashMap<String, Word>();
		while(videoDataSetIterator.hasNext()){
			Map.Entry<String,uTubeVideoData> entry = (Map.Entry<String,uTubeVideoData>) videoDataSetIterator.next();

			uTubeVideoData videoData = (uTubeVideoData)entry.getValue();
			
			String title  = videoData.getTitle().replaceAll("[^\\u0000-\\uFFFF]",""); // Replace non-alphanumeric characters			
			String author = videoData.getAuthor();	
			String delim = " &\t.,:;?!+-_/|{}()[]<>\"\'1234567890@";
			String strWord;	
			Word newWord;	
			harvis.textAreaDM.setText("\t" + titleNumber++ + " Parsing Words for Title : " + title );
			StringTokenizer st = new StringTokenizer(title, delim); 
			while (st.hasMoreTokens()) {
				strWord = st.nextToken().toLowerCase();	
				if (strWord.length() > 2){
					newWord = (Word) wordsMap.get(strWord); 
					if (newWord == null) {
						newWord = new Word(strWord, 1);
						newWord.addAuthor(author);
						wordsMap.put(strWord, newWord); 
					} else {
						newWord.addAuthor(author);
						newWord.wordCount++;						
					}						
				}
			}						
		}	
		// Remove words_2b_filtered from wordsMap
		StringTokenizer st = new StringTokenizer(words_2b_filtered, ","); 
		while (st.hasMoreTokens()) {
			String strFilterWord = st.nextToken().toLowerCase();	
			Word wordObj = wordsMap.get(strFilterWord);
			if (wordObj != null){  
				wordsMap.remove(strFilterWord);				
			}
		}
		// Remove seedQueryString from wordsMap (if exists)
		Word wordObj = wordsMap.get(seedQueryString.replaceAll("\"", ""));
		if (wordObj != null){  
			wordsMap.remove(seedQueryString.replaceAll("\"", ""));			
			System.out.println(seedQueryString + " is removed.") ;
		}
		Set<Map.Entry<String, Word>> set = wordsMap.entrySet(); 
		Iterator<Map.Entry<String, Word>> iter = set.iterator();
		int N = 10;
		if (N > videosCount)
			N = videosCount;
		Word topNWords[] = new Word[N];
		for (int i = 0; i < N; ){
			set = wordsMap.entrySet(); 
			iter = set.iterator();
			int maxAuthorCount = 0;
			while (iter.hasNext()) {
				Map.Entry<String, Word> entry = (Map.Entry<String, Word>) iter.next();				
				Word word = (Word) entry.getValue();
				if(word.authorCount > maxAuthorCount)
					maxAuthorCount = word.authorCount;
			}
			iter = set.iterator();
			while (iter.hasNext()) {
				Map.Entry<String, Word> entry = (Map.Entry<String, Word>) iter.next();				
				Word word = (Word) entry.getValue();
				if (word.authorCount == maxAuthorCount){		
					// Check if the word is already in the query string (e.g. Arabic music Arabic)
					Set<String> existingQuryStringsSet = evovledQueryObjects.keySet();
					Iterator<String> existingQueryStringsSetIter = existingQuryStringsSet.iterator();
					boolean wordContainedInQuery = false;
					while(existingQueryStringsSetIter.hasNext()){
						String existingQueryWord = existingQueryStringsSetIter.next();
						if (existingQueryWord.contains(word.word)){
							wordContainedInQuery = true;
							break;
						}
					}
					if (wordContainedInQuery == false){
						// Check if the word is not already selected as a search keyword
						if (evovledQueryObjects.get("\"" + seedQueryString.replaceAll("\"", "") + " " + word.word + "\"") == null)		{
							// Add the word to the list of uniqueKeyWords
							if (uniqueKeyWordsMap.get(word.word) == null)
								uniqueKeyWordsMap.put(word.word, word.word);
							// Include the word in topNWordsList
							topNWords[i] = word;	
							// Find the next topNWord
							i++;
						}
					}
					// Remove the word from wordsMap to find next best word
					iter.remove();
					break;
				}
			}
		}
		set = wordsMap.entrySet(); 
		iter = set.iterator();
		harvis.textAreaCrawler.setText("\t New Query Words" );
		for (int i = 0; i < N; i++){						
			try{
				harvis.textAreaCrawler.append("\n\t Word " + topNWords[i].word + 
												" Frequency "  + topNWords[i].wordCount + 
												" Authors " + topNWords[i].authorCount);
				uTubeQuery newQuery = new uTubeQuery(new URL(YOUTUBE_URL));
				// newQueryString = "querystring" newword
//				boolean isSeedQueryStringArabic = seedQueryString.replaceAll("\"", "").matches("[ ء-ي]+"); 
//				boolean isNewWordArabic = topNWords[i].word.matches("[ ء-ي]+");
//				if (relaxSelectionCriteria == false){					
//					if (isSeedQueryStringArabic && isNewWordArabic){					
//						newQuery.setFullTextQuery(seedQueryString.replaceAll("\"", "") + "\"" + " " + topNWords[i].word +"\"");					
//						newQuery.setQueryString(seedQueryString.replaceAll("\"", "") + "\"" + " " + topNWords[i].word +"\"");					
//					}else{
//						newQuery.setFullTextQuery("\"" + seedQueryString.replaceAll("\"", "") + "\"" + " " + topNWords[i].word);					
//						newQuery.setQueryString("\"" + seedQueryString.replaceAll("\"", "") + "\"" + " " + topNWords[i].word);
//					}
//				}else{
					newQuery.setFullTextQuery(seedQueryString.replaceAll("\"", "") + " " + topNWords[i].word );					
					newQuery.setQueryString(seedQueryString.replaceAll("\"", "") + " " + topNWords[i].word );
//				}
				System.out.println("New Query " + newQuery.getQueryString() );
				newQuery.setMaxResults(maxResults);
				newQuery.setSearchRound(1);
				newQuery.setTableNamePostFix(tableNamePostFix);
				// Check if the evolvedQueryObjects does not already have the query 
				uTubeQuery existingQuery  = evovledQueryObjects.get(newQuery.getQueryString());					
				if (existingQuery == null){
					// Add newQuery to evolvedQueryObjects			
					evovledQueryObjects.put(newQuery.getQueryString(), newQuery);
				}
				}catch(Exception e){
					e.printStackTrace();
				}			
		}		
		return evovledQueryObjects;
	}
//	private int fetchRelatedVideos(String seedQueryString){
//		Set<Map.Entry<String, uTubeVideoData>> dataSet = videoDataMap.entrySet();			 
//		Iterator<Map.Entry<String,uTubeVideoData>> iterator = dataSet.iterator();	
//		int videosReturnedByService = 0;
//		while(iterator.hasNext()){
//			Map.Entry<String, uTubeVideoData> entry = (Map.Entry<String,uTubeVideoData>) iterator.next();			
//			uTubeVideoData videoData = (uTubeVideoData)entry.getValue();
//			if ((videoData.getRelatedVideosFetched() == false) && (videoData.getRelatedVideosFeedUrl() != null)) {
//				uTubeQuery relatedVideosQuery = null;
//				try {					
//					relatedVideosQuery = new uTubeQuery(new URL(videoData.getRelatedVideosFeedUrl()));
//					relatedVideosQuery.setMaxResults(maxResults);
//					relatedVideosQuery.setStartIndex(1); // Related Videos Feed Is not affected by changing startIndex		
//					
//				} catch (MalformedURLException e) {					
//					e.printStackTrace();
//					continue;
//				}
//				VideoFeed relatedVideosFeed = null;
//				try{
//					relatedVideosFeed  = service.getFeed(relatedVideosQuery, VideoFeed.class);	
//					SERVICE_EXECUTION_COUNT++;
//				}catch(com.google.gdata.util.ServiceException | IOException serviceException){
//					harvis.textAreaCrawler.append("\n\n Exception fetching related videos : " + serviceException.getMessage() +"\n");
//					serviceException.printStackTrace();
//					continue;
//				}
//				for(VideoEntry relatedVideoEntry : relatedVideosFeed.getEntries() ) {
//					videosReturnedByService++;
//					String title = relatedVideoEntry.getTitle().getPlainText().toLowerCase();
//					String description = relatedVideoEntry.getMediaGroup().getDescription().getPlainTextContent().toLowerCase();										
//					boolean wordIsContainedInTitleOrDesc = false;
//					float matchRatio = wordsMatchRatio((title +" "+ description).toLowerCase());
//					
//					if (matchRatio >= .65)
//						wordIsContainedInTitleOrDesc = true; //(title + "\n" + description).toLowerCase().contains(keywords);
//					else 
//						wordIsContainedInTitleOrDesc = false;
//					if (wordIsContainedInTitleOrDesc){
//						String relatedVideoID = relatedVideoEntry.getId().substring(27).trim();
//						if (videoExistsInCollection(relatedVideoID) == false){
//							uTubeVideoData relatedVideoData = captureVideoData(relatedVideoEntry, relatedVideosQuery);
//							harvis.textAreaCrawler.append("\n\n\t Capturing video # " + getVideoCount() + " = " + relatedVideoData.getTitle() + "\n");												
//							addVideoData2Collection(relatedVideoData);
//						}else{
//							harvis.textAreaCrawler.append("\n\t Already captured... Ignoring video --> " +  title);
//						}
//					}else{
//						harvis.textAreaCrawler.append("\n\t Weak Relevance, Ignoring video --> " +  title);								
//					}			
//				} // End For Loop
//			}
//		}// End While	
//		return videosReturnedByService;
//	}
	private int executeAllQueries ( HashMap<String, uTubeQuery> evovledQueryObjects ){
		Set<java.util.Map.Entry<String, uTubeQuery>> querySet = evovledQueryObjects.entrySet();
		Iterator<java.util.Map.Entry<String, uTubeQuery>> querySetIterator = querySet.iterator();		
		ArrayList<uTubeQuery> querySummary = new ArrayList<uTubeQuery>();
		VedioV3Feed v3f=new VedioV3Feed(API_KEY,existVedioIDList);
		int videoCount = getVideoCount();
		int queryCount = 0;
		int videosReturnedByService = 1;
		for ( ; querySetIterator.hasNext() ; ){			
			Map.Entry<String, uTubeQuery> queryEntry = (Map.Entry<String, uTubeQuery>) querySetIterator.next();
			uTubeQuery query = queryEntry.getValue();
			//System.out.println(query.getFullUrl());
			String pageToken="";
			queryCount++;			
			if( query.isChecked() == false){				
					int startIndex = 1;					
					while(true){
						query.setStartIndex(startIndex);
						if (startIndex >= 950)
							query.setMaxResults(999-startIndex);
						harvis.textAreaCrawler.append("\n\n New Query String: " + query.getQueryString() + "\t Search Round: " + SEARCH_ROUND);
						harvis.textAreaCrawler.append("\n Invoking service # " +SERVICE_EXECUTION_COUNT+" for Query # "+queryCount+" / " + evovledQueryObjects.size() + ".");						
						harvis.textAreaCrawler.append("\n Query URL :" + query.getFullUrl() + "\n");
						List<searchvideo.v3.VideoEntry> videoFeed = null;
						
						try{
							Thread.sleep(1000);
							//videoFeed = service.getFeed(query, VideoFeed.class);
							System.out.println(query.getQueryString());
							videoFeed=v3f.getVedioInformations(query.getQueryString(),50,pageToken);
							SERVICE_EXECUTION_COUNT++;	
							pageToken=v3f.getNextPageToken();
						}catch(VideoNotFoundException e){
							harvis.textAreaCrawler.append("\n\n Exception fetching videos : " + e.getMessage() +"\n");
							startIndex++;
							break;
						} catch (InterruptedException e) {							
							e.printStackTrace();
							harvis.textAreaCrawler.append("\n\n Exception sleeping : " + e.getMessage() +"\n");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}						
						int videoFeedIndex = 0;
						for(searchvideo.v3.VideoEntry oneVideo : videoFeed ) {							
							videoFeedIndex++;
							videosReturnedByService++;
							String title = oneVideo.getTitle().getPlainText().toLowerCase();
							String description = oneVideo.getDescription().toLowerCase();
							String author = oneVideo.getAuthors().get(0).getName();
							String keywords = query.getQueryString();
							
							keywords = keywords.replace(author, ""); // remove author name from keywords to avoid selecting irrelevant videos
							keywords = keywords.replace("\"", ""); // remove commas from keywords to avoid selecting irrelevant videos
							keywords = keywords.replace("+", " ").trim().toLowerCase();
							String trimmedID = oneVideo.getId();
				        	if (trimmedID.equals("hUGkBHkOlTA"))
				        		System.out.println("Got it");
							boolean wordIsContainedInTitleOrDesc = wordsMatchExists((title +" "+ description).toLowerCase(), true);
							//float matchRatio = wordsMatchRatio((title +" "+ description).toLowerCase());							
//							if (matchRatio > 0)
//								wordIsContainedInTitleOrDesc = true; //(title + "\n" + description).toLowerCase().contains(keywords);
//							else 
//								wordIsContainedInTitleOrDesc = false;
													
							if (wordIsContainedInTitleOrDesc){
								String videoID = oneVideo.getId();
								if (videoExistsInCollection(videoID) == false){
									uTubeVideoData videoData = captureVideoData(oneVideo, query);
									harvis.textAreaCrawler.append("\n\n\t Capturing video # " + getVideoCount() + " = " + videoData.getTitle() +"\n");
									addVideoData2Collection(videoData);
								}else {
									harvis.textAreaCrawler.append("\n\n\t Video Already Captured. " + title);
								}
							}else{
								harvis.textAreaCrawler.append("\n\n\t Weak Relevance. Ignoring video " + oneVideo.getTitle() +"\n");
							}
						} // FOR ENDS HERE
						// Sleep for a while
						double d = Math.random()*20*1000;
						int sleepTime = (int)d;
						//System.out.println("Going to sleep for " + (sleepTime/1000) + " seconds.");
						try {
							Thread.sleep(sleepTime);
						} catch (InterruptedException e) {							
							e.printStackTrace();
						}
						//System.out.println("Woke up !");
						int cnt=getVideoCount();
						if (cnt > videoCount){	
							harvis.campaignManager.threadManager.setVideoData(videoDataMap);
							videoCount = getVideoCount();							
							harvis.textAreaCrawler.setText("\n ***** Setting batch of " + videoCount + " videos data");
						}else{
							harvis.textAreaCrawler.append("\n no results returned from this startIndex; Don't check next number and move on...");
							break; // no results returned from this startIndex; Don't check next number and move on...
						}
						startIndex += videoFeedIndex;
						harvis.textAreaCrawler.setText("\n Crawling through " + startIndex +" index of current Query");
						if (startIndex > 999)
							break;			
						if ( videoFeedIndex == 0)
							break;	
						if(SERVICE_EXECUTION_COUNT>5 || pageToken.equals("") || pageToken==null)
							break;
						
						}// WHILE ENDS HERE
					harvis.textAreaCrawler.append("\n Total "+ videosReturnedByService + " videos returned by service \n");
					query.setChecked();
					querySummary.add(query);
					harvis.textAreaCrawler.setText("\n Query String : " + query.getQueryString() );
					harvis.textAreaCrawler.append("\n Query # "+queryCount+" / " + evovledQueryObjects.size() + " finished... moving  to next.");
			}		
			else{
				harvis.textAreaCrawler.setText("\n Query String : " + query.getQueryString() );
				harvis.textAreaCrawler.append("\n Query # "+queryCount+" / " + evovledQueryObjects.size() + " is checked ... moving  to next.");
			}				
		}
		harvis.textAreaCrawler.setText("\n Finished All Queries for Search Round: " + SEARCH_ROUND );
		return videosReturnedByService;
	}
	
	public void run(){
		// Load Filter Words
		loadFilterWords();
		
		// build uniqueKeyWordsMap (to be used in wordsMatchRatio())		
		Set<String> queryStringsMapKeySet = queryStringsMap.keySet();								 
		Iterator<String> queryStringsMapKeySetSetIterator = queryStringsMapKeySet.iterator();
		String allQueryStrings = "";
		while(queryStringsMapKeySetSetIterator.hasNext()){			
			HashMap<String, uTubeQuery> queryObjects = queryStringsMap.get(queryStringsMapKeySetSetIterator.next());
			Set<String> queryStringsKeySet = queryObjects.keySet();
			Iterator<String> queryStringsKeySetIterator = queryStringsKeySet.iterator();
			while (queryStringsKeySetIterator.hasNext()){
				allQueryStrings += queryStringsKeySetIterator.next().replace("\"", "") + " ";
			}	
		}
		
		StringReader keyWordsStringReader = new StringReader(allQueryStrings);
		BufferedReader keyWordsReader = new BufferedReader(keyWordsStringReader);
		uniqueKeyWordsMap = new HashMap<String, String>();
		try {
			String keyWordsLine = "";
			String delim = " ";
			while((keyWordsLine = keyWordsReader.readLine()) != null){
				StringTokenizer mustKeyWordsTokenizer = new StringTokenizer(keyWordsLine, delim); 
				while (mustKeyWordsTokenizer.hasMoreTokens()) {
					String word = mustKeyWordsTokenizer.nextToken();
					if (uniqueKeyWordsMap.get(word) == null){						
						uniqueKeyWordsMap.put(word, word);						
					}					
				}				
			}
			keyWordsStringReader.close();
			keyWordsReader.close();
		} catch (IOException e1) {			
			e1.printStackTrace();
		}
		
		HashMap<String, uTubeQuery> evovledQueryObjects = null;		
		
		int videosCountPrev = getVideoCount();

		Set<java.util.Map.Entry<String, HashMap<String, uTubeQuery>>> queryStringsEntrySet = queryStringsMap.entrySet();							 
		Iterator<java.util.Map.Entry<String, HashMap<String, uTubeQuery>>> queryStringsEntrySetIterator = queryStringsEntrySet.iterator();	

		while (queryStringsEntrySetIterator.hasNext()) {
			Map.Entry<String, HashMap<String, uTubeQuery>> entry = (Map.Entry<String, HashMap<String, uTubeQuery>>) queryStringsEntrySetIterator.next();
			String seedQueryString = entry.getKey();
			HashMap<String, uTubeQuery> existingQueriesMap  = entry.getValue();
			SEARCH_ROUND = existingQueriesMap.get(seedQueryString).getSearchRound();
			uTubeQuery uTubeQuery=existingQueriesMap.get(seedQueryString);
			do{
				evovledQueryObjects = evolveQueryByTitles(seedQueryString,uTubeQuery.getTableNamePostFix());					
				evovledQueryObjects.get(seedQueryString).setSearchRound(SEARCH_ROUND);

				Calendar startTime = Calendar.getInstance();
				int videosReturnedByService = executeAllQueries(evovledQueryObjects);
				// videosReturnedByService += fetchRelatedVideos(seedQueryString);
				Calendar endTime = Calendar.getInstance();			

				long timeInMillis = endTime.getTimeInMillis() - startTime.getTimeInMillis();
				int timeInMinutes = (int)((timeInMillis/1000)/60);

				int videosCountAfter = getVideoCount();					
				harvis.campaignManager.uTubeDM.insertSearchRoundRecordIntoDB(
						seedQueryString, 
						uTubeQuery.getTableNamePostFix(),		//SeedQueryString
						SEARCH_ROUND, 							// SearchRound
						timeInMinutes, 							// TimeInMinutes
						(videosCountAfter - videosCountPrev), 	// VideosCount
						SERVICE_EXECUTION_COUNT,				// ServiceExecutionCount
						videosReturnedByService);				// VideosReturnedByService
				SERVICE_EXECUTION_COUNT = 0;				
				videosCountPrev = videosCountAfter;
			}while(SEARCH_ROUND++ < 3);						
		}							

		
		int vidCount = getVideoCount();
		harvis.textAreaCrawler.append("\n\n\t uTubeCrawler: Crawler has found " + vidCount + " videos...");				
		if (vidCount >= 1){
			harvis.campaignManager.threadManager.setVideoData(videoDataMap);
		}
		harvis.textAreaCrawler.append("\n\n\t uTubeCrawler: *%*%*%*%*%*% FINISHED CRAWLING *%*%*%*%*%*%*%*");
		harvis.textAreaCrawler.append("\n\n\t uTubeCrawler: *%*%*%*%*%*% EXTRACTED VIDEOS COUNT = "+ getVideoCount() +"*%*%*%*%*%*%*%*");
		harvis.textAreaCrawler.append("\n\n\t uTubeCrawler: *%*%*%*%*%*% Queries LIST *%*%*%*%*%*%*%*");
		Set<java.util.Map.Entry<String, uTubeQuery>> querySet = evovledQueryObjects.entrySet();			
		Iterator<java.util.Map.Entry<String, uTubeQuery>> querySetIterator = querySet.iterator();
		for ( ; querySetIterator.hasNext(); ){
			Map.Entry<String, uTubeQuery> queryEntry = (Map.Entry<String, uTubeQuery>) querySetIterator.next();
			uTubeQuery query = queryEntry.getValue();
			harvis.textAreaCrawler.append("\n\n\t\t Feed URL: "+ query.getFullUrl());
		}		
	}	
}

class uTubeFeedUrl{
	private String seedString = "";
	private int startIndex = 1;
	private String category = null;
	private int maxResults = 50;
	private int version = 2;
	private String feedUrl;
	private String googleUrl = "http://gdata.youtube.com/feeds/api/videos?";
	
	public uTubeFeedUrl(String seedString, String Category, int startIndex, int maxResults, int version){
		feedUrl = googleUrl;
		feedUrl += "q="+ seedString;
		feedUrl += "&start-index="+ startIndex;
		feedUrl += "&search_sort=video_view_count";
		if (category != null)
			feedUrl += "&category="+ category; //example News%7CPolitics"
		if (maxResults > 0 ) 
				feedUrl += "&max-results=" + maxResults;
		feedUrl += "&v=2";
	}	
	public uTubeFeedUrl(){
		feedUrl = "http://gdata.youtube.com/feeds/api/videos?";
	}
	void getFeedUrl(){
		 
	}
	void resetCategory(String category){
		
	}
}
